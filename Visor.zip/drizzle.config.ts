import { config as loadDotenv } from "dotenv";
import { defineConfig } from "drizzle-kit";

// Shell/Vercel variables win; .env.local takes precedence over .env locally.
loadDotenv({ path: ".env.local", quiet: true });
loadDotenv({ path: ".env", quiet: true });

// Neon recommends an unpooled connection for schema migrations.
const migrationUrl =
  process.env.DATABASE_URL_UNPOOLED?.trim() || process.env.DATABASE_URL?.trim();

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  ...(migrationUrl ? { dbCredentials: { url: migrationUrl } } : {}),
  strict: true,
  verbose: true,
});
