import Link from "next/link";
import { CONTACTS, type Locale } from "@/lib/constants";
import type { Dictionary } from "@/i18n";
import { Icon, Logo } from "./icons";

export function Footer({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  return (
    <footer className="mt-20 border-t border-white/10 bg-[#070a0f]">
      <div className="container-page py-14">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/55">
              {dict.footer.tagline}
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {[dict.common.freeDelivery, dict.common.cod, dict.common.guarantee].map(
                (tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-1 text-[0.6875rem] text-white/60"
                  >
                    {tag}
                  </span>
                ),
              )}
            </div>
          </div>

          <div>
            <h3 className="text-[0.6875rem] font-semibold uppercase tracking-[0.18em] text-white/40">
              {dict.footer.productTitle}
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-white/65">
              <li>
                <Link href={`/${locale}#lenses`} className="hover:text-[var(--color-brand)]">
                  {dict.nav.lenses}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}#how`} className="hover:text-[var(--color-brand)]">
                  {dict.nav.how}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}#offer`} className="hover:text-[var(--color-brand)]">
                  {dict.offer.eyebrow}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}#reviews`} className="hover:text-[var(--color-brand)]">
                  {dict.nav.reviews}
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-[0.6875rem] font-semibold uppercase tracking-[0.18em] text-white/40">
              {dict.footer.helpTitle}
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-white/65">
              <li>
                <Link href={`/${locale}/info/delivery`} className="hover:text-[var(--color-brand)]">
                  {dict.footer.delivery}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}/info/warranty`} className="hover:text-[var(--color-brand)]">
                  {dict.footer.warranty}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}/track`} className="hover:text-[var(--color-brand)]">
                  {dict.footer.track}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}#faq`} className="hover:text-[var(--color-brand)]">
                  {dict.footer.faq}
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-[0.6875rem] font-semibold uppercase tracking-[0.18em] text-white/40">
              {dict.footer.contactsTitle}
            </h3>
            <ul className="mt-4 space-y-3 text-sm text-white/70">
              <li>
                <a href={CONTACTS.phoneHref} className="flex items-center gap-2.5 hover:text-white">
                  <Icon name="phone" className="h-4 w-4 text-[var(--color-brand)]" />
                  {CONTACTS.phone}
                </a>
              </li>
              <li>
                <a
                  href={CONTACTS.telegram}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2.5 hover:text-white"
                >
                  <Icon name="telegram" className="h-4 w-4 text-[var(--color-brand)]" />
                  {CONTACTS.telegramHandle}
                </a>
              </li>
              <li>
                <a
                  href={CONTACTS.instagram}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2.5 hover:text-white"
                >
                  <Icon name="instagram" className="h-4 w-4 text-[var(--color-brand)]" />
                  {CONTACTS.instagramHandle}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${CONTACTS.email}`}
                  className="flex items-center gap-2.5 hover:text-white"
                >
                  <Icon name="card" className="h-4 w-4 text-[var(--color-brand)]" />
                  {CONTACTS.email}
                </a>
              </li>
              <li className="flex items-center gap-2.5 text-white/50">
                <Icon name="pin" className="h-4 w-4" />
                {CONTACTS.city[locale]} · {dict.footer.hours}
              </li>
            </ul>
          </div>
        </div>

        <div className="divider my-8" />

        <div className="flex flex-col gap-4 text-xs text-white/40 md:flex-row md:items-center md:justify-between">
          <p>
            © {new Date().getFullYear()} Carstore_sam. {dict.footer.rights}
          </p>
          <div className="flex flex-wrap items-center gap-4">
            <span className="flex items-center gap-1.5">
              <Icon name="card" className="h-4 w-4" />
              Uzcard · Humo
            </span>
            <Link href={`/${locale}/admin`} className="hover:text-white/70">
              {dict.footer.admin}
            </Link>
          </div>
        </div>
        <p className="mt-4 max-w-3xl text-[0.6875rem] leading-relaxed text-white/25">
          {dict.footer.disclaimer}
        </p>
      </div>
    </footer>
  );
}
