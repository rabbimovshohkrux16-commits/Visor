"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { Locale } from "@/lib/constants";
import { formatPrice } from "@/lib/format";
import { Icon } from "./icons";

export function StickyBar({
  locale,
  price,
  label,
}: {
  locale: Locale;
  price: number;
  label: string;
}) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 520);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-[#070a0f]/95 px-4 py-3 backdrop-blur-xl transition-transform duration-300 md:hidden ${
        visible ? "translate-y-0" : "translate-y-full"
      }`}
      style={{ paddingBottom: "calc(0.75rem + env(safe-area-inset-bottom))" }}
    >
      <div className="flex items-center gap-3">
        <div className="min-w-0 flex-1">
          <p className="truncate text-[0.625rem] uppercase tracking-[0.14em] text-white/45">
            Carstore_sam · Day &amp; Night visor
          </p>
          <p className="text-base font-extrabold text-white">{formatPrice(price, locale)}</p>
        </div>
        <Link href={`/${locale}#order`} className="btn btn-primary shrink-0 !px-5 !py-2.5">
          {label}
          <Icon name="arrow" className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
