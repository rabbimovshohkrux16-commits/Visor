"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import type { Dictionary } from "@/i18n";
import type { Locale } from "@/lib/constants";
import { Icon } from "./icons";

export function TrackForm({
  locale,
  dict,
  initialCode = "",
}: {
  locale: Locale;
  dict: Dictionary;
  initialCode?: string;
}) {
  const router = useRouter();
  const [code, setCode] = useState(initialCode);
  const [loading, startTransition] = useTransition();

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        if (!code.trim()) return;
        startTransition(() => {
          router.push(`/${locale}/track?code=${encodeURIComponent(code.trim())}`);
        });
      }}
      className="flex flex-col gap-2.5 sm:flex-row"
    >
      <input
        value={code}
        onChange={(event) => setCode(event.target.value)}
        placeholder={dict.track.placeholder}
        aria-label={dict.order.codeLabel}
        className="field flex-1"
      />
      <button type="submit" disabled={loading} className="btn btn-primary shrink-0">
        <Icon name="search" className="h-4 w-4" />
        {dict.track.submit}
      </button>
    </form>
  );
}
