"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import type { Dictionary } from "@/i18n";
import type { Locale } from "@/lib/constants";
import { REGIONS } from "@/lib/constants";
import type { BundleView } from "@/lib/bundles-data";
import { formatNumber, formatPrice, normalizePhone } from "@/lib/format";
import { Icon } from "./icons";

type Fields = {
  name: string;
  phone: string;
  region: string;
  city: string;
  address: string;
  comment: string;
};

type ErrorKey = keyof Dictionary["form"]["errors"];

export function OrderForm({
  locale,
  dict,
  bundles,
}: {
  locale: Locale;
  dict: Dictionary;
  bundles: BundleView[];
}) {
  const router = useRouter();
  const [bundleCode, setBundleCode] = useState(bundles[0]?.code ?? "single");
  const [delivery, setDelivery] = useState<"courier" | "pickup">("courier");
  const [fields, setFields] = useState<Fields>({
    name: "",
    phone: "",
    region: "",
    city: "",
    address: "",
    comment: "",
  });
  const [errors, setErrors] = useState<Partial<Record<ErrorKey, string>>>({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const selected = useMemo(
    () => bundles.find((bundle) => bundle.code === bundleCode) ?? bundles[0],
    [bundleCode, bundles],
  );

  const set = (key: keyof Fields, value: string) => {
    setFields((prev) => ({ ...prev, [key]: value }));
    if (key in errors) {
      setErrors((prev) => ({ ...prev, [key]: undefined }));
    }
  };

  const validate = () => {
    const next: Partial<Record<ErrorKey, string>> = {};
    if (fields.name.trim().length < 2) next.name = dict.form.errors.name;
    if (!normalizePhone(fields.phone)) next.phone = dict.form.errors.phone;
    if (!fields.region) next.region = dict.form.errors.region;
    if (fields.city.trim().length < 2) next.city = dict.form.errors.city;
    if (delivery === "courier" && fields.address.trim().length < 4)
      next.address = dict.form.errors.address;
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setServerError(null);
    if (!validate() || !selected) return;

    const params = new URLSearchParams(window.location.search);
    const sourceParts = ["utm_source", "utm_medium", "utm_campaign"]
      .map((key) => params.get(key))
      .filter(Boolean);
    const source = sourceParts.length ? sourceParts.join(" / ") : params.get("ref") || null;

    setSubmitting(true);
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          locale,
          bundleCode: selected.code,
          ...fields,
          deliveryMethod: delivery,
          paymentMethod: "card_on_delivery",
          source,
        }),
      });
      const data = (await response.json()) as { ok?: boolean; code?: string; error?: string };
      if (!response.ok || !data.ok || !data.code) {
        if (data.error === "name") setErrors({ name: dict.form.errors.name });
        else if (data.error === "phone") setErrors({ phone: dict.form.errors.phone });
        else setServerError(dict.form.errors.generic);
        setSubmitting(false);
        return;
      }
      router.push(`/${locale}/order/${data.code}`);
    } catch {
      setServerError(dict.form.errors.generic);
      setSubmitting(false);
    }
  };

  if (!selected) {
    return (
      <div className="card p-5 text-sm text-white/70 sm:p-7">
        {dict.common.outOfStock}
      </div>
    );
  }

  const inputClass = (hasError?: string) =>
    `field ${hasError ? "!border-red-400/70" : ""}`;

  return (
    <div className="card relative overflow-hidden p-5 shadow-[var(--shadow-card)] sm:p-7">
      <div className="pointer-events-none absolute -right-16 -top-20 h-48 w-48 rounded-full bg-[var(--color-brand)]/15 blur-3xl" />
      <div className="relative">
        <h3 className="text-xl font-bold tracking-tight sm:text-2xl">{dict.form.title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-white/55">{dict.form.subtitle}</p>

        <form onSubmit={onSubmit} className="mt-6 space-y-4" noValidate>
          {/* 1. Name */}
          <div>
            <label htmlFor="name" className="field-label">
              {dict.form.name} *
            </label>
            <input
              id="name"
              className={inputClass(errors.name)}
              autoComplete="name"
              placeholder={dict.form.namePlaceholder}
              value={fields.name}
              onChange={(event) => set("name", event.target.value)}
              aria-invalid={!!errors.name}
            />
            {errors.name && <p className="mt-1 text-xs text-red-400">{errors.name}</p>}
          </div>

          {/* 2. Phone */}
          <div>
            <label htmlFor="phone" className="field-label">
              {dict.form.phone} *
            </label>
            <input
              id="phone"
              className={inputClass(errors.phone)}
              inputMode="tel"
              autoComplete="tel"
              placeholder={dict.form.phonePlaceholder}
              value={fields.phone}
              onChange={(event) => set("phone", event.target.value)}
              aria-invalid={!!errors.phone}
            />
            {errors.phone && <p className="mt-1 text-xs text-red-400">{errors.phone}</p>}
          </div>

          {/* 3. Region */}
          <div>
            <label htmlFor="region" className="field-label">
              {dict.form.region} *
            </label>
            <select
              id="region"
              className={`${inputClass(errors.region)} appearance-none`}
              value={fields.region}
              onChange={(event) => set("region", event.target.value)}
              aria-invalid={!!errors.region}
            >
              <option value="">{dict.form.regionPlaceholder}</option>
              {REGIONS.map((region) => (
                <option key={region.value} value={region.value} className="bg-[#11161f]">
                  {region.label[locale]}
                </option>
              ))}
            </select>
            {errors.region && <p className="mt-1 text-xs text-red-400">{errors.region}</p>}
          </div>

          {/* 4. City / district */}
          <div>
            <label htmlFor="city" className="field-label">
              {dict.form.city} *
            </label>
            <input
              id="city"
              className={inputClass(errors.city)}
              placeholder={dict.form.cityPlaceholder}
              value={fields.city}
              onChange={(event) => set("city", event.target.value)}
              aria-invalid={!!errors.city}
            />
            {errors.city && <p className="mt-1 text-xs text-red-400">{errors.city}</p>}
          </div>

          {/* 5. Delivery method — courier | pickup side by side */}
          <div>
            <span className="field-label">{dict.form.delivery}</span>
            <div className="grid grid-cols-2 gap-2">
              {[
                { key: "courier" as const, label: dict.form.deliveryCourier, icon: "truck" as const },
                { key: "pickup" as const, label: dict.form.deliveryPickup, icon: "pin" as const },
              ].map((option) => (
                <button
                  key={option.key}
                  type="button"
                  onClick={() => setDelivery(option.key)}
                  aria-pressed={delivery === option.key}
                  className={`flex items-center gap-2 rounded-xl border px-3 py-3 text-left text-[0.8125rem] leading-snug transition ${
                    delivery === option.key
                      ? "border-[var(--color-brand)] bg-[var(--color-brand)]/10 text-white"
                      : "border-white/10 text-white/60 hover:border-white/25"
                  }`}
                >
                  <Icon name={option.icon} className="h-4 w-4 shrink-0 text-[var(--color-brand)]" />
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {/* 6. Address (courier only) */}
          {delivery === "courier" && (
            <div>
              <label htmlFor="address" className="field-label">
                {dict.form.address} *
              </label>
              <input
                id="address"
                className={inputClass(errors.address)}
                autoComplete="street-address"
                placeholder={dict.form.addressPlaceholder}
                value={fields.address}
                onChange={(event) => set("address", event.target.value)}
                aria-invalid={!!errors.address}
              />
              {errors.address && <p className="mt-1 text-xs text-red-400">{errors.address}</p>}
            </div>
          )}

          {/* 7. Comment */}
          <div>
            <label htmlFor="comment" className="field-label">
              {dict.form.comment}
            </label>
            <input
              id="comment"
              className="field"
              placeholder={dict.form.commentPlaceholder}
              value={fields.comment}
              onChange={(event) => set("comment", event.target.value)}
            />
          </div>

          {/* 8. Product + price (auto) */}
          <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[0.625rem] font-semibold uppercase tracking-[0.14em] text-white/40">
                  {dict.form.product}
                </p>
                <p className="mt-1 text-sm font-semibold text-white">{dict.form.productName}</p>
                <p className="text-[0.6875rem] text-white/45">{dict.lenses.title}</p>
              </div>
              <div className="text-right">
                <p className="text-base font-extrabold text-white">
                  {formatNumber(selected.price)}
                </p>
                <p className="text-[0.6875rem] text-white/35 line-through">
                  {formatNumber(selected.compareAt)}
                </p>
              </div>
            </div>

            <div className="mt-3">
              <span className="text-[0.625rem] font-semibold uppercase tracking-[0.14em] text-white/40">
                {dict.form.chooseBundle}
              </span>
              <div className="mt-1.5 grid grid-cols-3 gap-2">
                {bundles.map((bundle) => {
                  const active = bundle.code === bundleCode;
                  return (
                    <button
                      key={bundle.code}
                      type="button"
                      onClick={() => setBundleCode(bundle.code)}
                      aria-pressed={active}
                      className={`relative rounded-xl border px-2 py-2 text-center transition ${
                        active
                          ? "border-[var(--color-brand)] bg-[var(--color-brand)]/12"
                          : "border-white/10 hover:border-white/25"
                      }`}
                    >
                      <span className="block text-sm font-bold text-white">
                        {bundle.qty} {dict.common.each}
                      </span>
                      <span className="block text-[0.625rem] text-white/50">
                        {formatNumber(bundle.price)}
                      </span>
                      {bundle.badge === "popular" && (
                        <span className="absolute -top-2 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-[var(--color-brand)] px-1.5 py-0.5 text-[0.5rem] font-bold uppercase tracking-wide text-[#16110a]">
                          {dict.common.popular}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-4 space-y-2 border-t border-white/8 pt-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-white/55">{dict.form.product}</span>
                <span className="font-semibold text-white">{formatPrice(selected.price, locale)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/55">{dict.form.deliveryPrice}</span>
                <span className="font-semibold text-[var(--color-brand)]">{dict.form.deliveryValue}</span>
              </div>
              <p className="text-[0.6875rem] leading-snug text-white/35">{dict.form.deliveryHint}</p>
              <div className="flex items-center justify-between border-t border-white/8 pt-3">
                <span className="font-semibold text-white">{dict.form.total}</span>
                <span className="text-lg font-extrabold text-[var(--color-brand)]">
                  {formatPrice(selected.price, locale)}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-2.5 rounded-xl border border-white/8 bg-white/[0.02] px-3.5 py-3">
            <Icon name="card" className="mt-0.5 h-4 w-4 shrink-0 text-[var(--color-mint)]" />
            <div>
              <p className="text-xs font-semibold text-white/80">{dict.form.payment}</p>
              <p className="mt-0.5 text-[0.6875rem] text-white/45">{dict.form.paymentCod}</p>
            </div>
          </div>

          {serverError && (
            <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300">
              {serverError}
            </p>
          )}

          {/* 9. Yellow confirm button */}
          <button type="submit" disabled={submitting} className="btn btn-primary w-full text-base">
            {submitting ? dict.form.submitting : dict.form.submit}
            <Icon name="arrow" className="h-4 w-4" />
          </button>

          <p className="text-center text-[0.6875rem] leading-relaxed text-white/35">
            {dict.form.privacy}
          </p>
        </form>
      </div>
    </div>
  );
}
