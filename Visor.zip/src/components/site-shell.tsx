import type { ReactNode } from "react";
import type { Locale } from "@/lib/constants";
import type { Dictionary } from "@/i18n";
import { Header } from "./header";
import { Footer } from "./footer";
import { Icon } from "./icons";
import { CONTACTS } from "@/lib/constants";

export function SiteShell({
  locale,
  dict,
  children,
}: {
  locale: Locale;
  dict: Dictionary;
  children: ReactNode;
}) {
  return (
    <>
      <Header locale={locale} dict={dict} />
      <main className="pt-16 md:pt-[72px]">{children}</main>
      <Footer locale={locale} dict={dict} />
      <a
        href={CONTACTS.telegram}
        target="_blank"
        rel="noreferrer"
        aria-label="Telegram"
        className="fixed bottom-24 right-4 z-40 grid h-12 w-12 place-items-center rounded-full border border-white/15 bg-[#11161f] text-[var(--color-brand)] shadow-[0_12px_30px_-10px_rgba(0,0,0,0.9)] transition hover:border-[var(--color-brand)]/50 hover:bg-[#171e29] md:bottom-6 md:right-6"
      >
        <Icon name="telegram" className="h-5 w-5" />
      </a>
    </>
  );
}
