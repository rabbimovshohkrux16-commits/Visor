"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import type { Dictionary } from "@/i18n";
import type { Locale } from "@/lib/constants";
import { Icon, Stars } from "./icons";
import { formatPrice } from "@/lib/format";

export function Hero({
  dict,
  locale,
  rating,
  reviewCount,
  fromPrice,
  comparePrice,
  todayOrders,
}: {
  dict: Dictionary;
  locale: Locale;
  rating: number;
  reviewCount: number;
  fromPrice: number | null;
  comparePrice: number | null;
  todayOrders: number;
}) {
  const [mode, setMode] = useState<"day" | "night">("day");
  const isDay = mode === "day";

  return (
    <section className="relative overflow-hidden">
      <div
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(900px 500px at 78% -5%, rgba(255,176,32,0.18), transparent 65%), radial-gradient(700px 460px at 8% 12%, rgba(80,120,220,0.14), transparent 60%)",
        }}
      />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-px"
        style={{
          background:
            "linear-gradient(90deg, transparent, rgba(255,176,32,0.5), transparent)",
        }}
      />

      <div className="container-page grid items-center gap-12 pb-14 pt-10 md:pb-20 md:pt-16 lg:grid-cols-[1.02fr_1fr] lg:gap-14">
        <div className="animate-float-in">
          <span className="inline-flex items-center gap-2 rounded-full border border-[var(--color-brand)]/35 bg-[var(--color-brand)]/10 px-3.5 py-1.5 text-[0.6875rem] font-semibold uppercase tracking-[0.16em] text-[#ffce6b]">
            <Icon name="sun" className="h-3.5 w-3.5" />
            {dict.hero.eyebrow}
          </span>

          <h1 className="mt-5 text-[2.15rem] font-extrabold leading-[1.04] tracking-tight sm:text-5xl lg:text-[3.35rem]">
            {dict.hero.title}
          </h1>

          <p className="mt-5 max-w-xl text-[0.975rem] leading-relaxed text-white/60 sm:text-base">
            {dict.hero.subtitle}
          </p>

          <ul className="mt-6 space-y-2.5">
            {dict.hero.bullets.map((bullet) => (
              <li key={bullet} className="flex items-start gap-2.5 text-sm text-white/75">
                <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[var(--color-mint)]/12 text-[var(--color-mint)]">
                  <Icon name="check" className="h-3 w-3" strokeWidth={2.6} />
                </span>
                {bullet}
              </li>
            ))}
          </ul>

          <div className="mt-7 flex flex-wrap items-end gap-x-4 gap-y-2">
            {fromPrice !== null ? (
              <>
                <div className="flex items-baseline gap-2.5">
                  <span className="text-3xl font-extrabold tracking-tight text-white">
                    {formatPrice(fromPrice, locale)}
                  </span>
                  {comparePrice !== null && comparePrice > fromPrice && (
                    <span className="text-sm text-white/35 line-through">
                      {formatPrice(comparePrice, locale)}
                    </span>
                  )}
                </div>
                <span className="inline-flex items-center gap-2 rounded-full border border-[var(--color-mint)]/25 bg-[var(--color-mint)]/8 px-3 py-1 text-[0.6875rem] font-semibold text-[var(--color-mint)]">
                  <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-[var(--color-mint)]" />
                  {dict.common.inStock}
                </span>
              </>
            ) : (
              <span className="text-lg font-semibold text-white/70">{dict.common.outOfStock}</span>
            )}
          </div>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Link href={`/${locale}#order`} className="btn btn-primary flex-1 sm:flex-none">
              {dict.hero.ctaPrimary}
              <Icon name="arrow" className="h-4 w-4" />
            </Link>
            <Link href={`/${locale}#how`} className="btn btn-ghost flex-1 sm:flex-none">
              {dict.hero.ctaSecondary}
            </Link>
          </div>

          {(reviewCount > 0 || todayOrders > 0) && (
            <div className="mt-7 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
              {reviewCount > 0 && (
                <>
                  <Stars rating={rating} />
                  <span className="font-semibold text-white">{rating.toFixed(1)}</span>
                  <span className="text-white/40">· {reviewCount} {dict.reviewsSection.basedOn}</span>
                </>
              )}
              {reviewCount > 0 && todayOrders > 0 && <span className="hidden h-4 w-px bg-white/15 sm:block" />}
              {todayOrders > 0 && (
                <span className="text-[0.8125rem] text-white/45">{todayOrders} {dict.common.todayOrders}</span>
              )}
            </div>
          )}
        </div>

        <div className="animate-float-in [animation-delay:120ms]">
          <div className="card relative overflow-hidden p-2 shadow-[var(--shadow-card)]">
            <div className="relative aspect-[4/4.35] overflow-hidden rounded-[1.25rem] bg-[#0a0d12] sm:aspect-[4/3.7] lg:aspect-[4/4.2]">
              <Image
                src="/images/hero-visor.jpg"
                alt={dict.hero.heroImageAlt}
                fill
                priority
                sizes="(max-width: 1024px) 100vw, 520px"
                className={`object-cover transition-all duration-700 ${
                  isDay ? "opacity-100" : "opacity-0"
                }`}
              />
              <Image
                src="/images/night-lens.jpg"
                alt={dict.hero.nightTitle}
                fill
                sizes="(max-width: 1024px) 100vw, 520px"
                className={`object-cover transition-all duration-700 ${
                  isDay ? "opacity-0" : "opacity-100"
                }`}
              />

              <div className="absolute inset-x-0 top-0 flex items-center justify-between p-3.5">
                <div className="flex rounded-full border border-white/15 bg-black/45 p-1 backdrop-blur-md">
                  <button
                    type="button"
                    onClick={() => setMode("day")}
                    aria-pressed={isDay}
                    className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                      isDay ? "bg-white text-[#14100a]" : "text-white/75 hover:text-white"
                    }`}
                  >
                    <Icon name="sun" className="h-3.5 w-3.5" />
                    {dict.common.day}
                  </button>
                  <button
                    type="button"
                    onClick={() => setMode("night")}
                    aria-pressed={!isDay}
                    className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                      !isDay ? "bg-white text-[#14100a]" : "text-white/75 hover:text-white"
                    }`}
                  >
                    <Icon name="moon" className="h-3.5 w-3.5" />
                    {dict.common.night}
                  </button>
                </div>
                <span className="rounded-full border border-white/15 bg-black/45 px-2.5 py-1 text-[0.625rem] font-semibold uppercase tracking-[0.14em] text-white/80 backdrop-blur-md">
                  Carstore_sam
                </span>
              </div>

              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/92 via-black/60 to-transparent p-4 pt-16 sm:p-5 sm:pt-20">
                <p className="text-[0.625rem] font-semibold uppercase tracking-[0.18em] text-[var(--color-brand)]">
                  {isDay ? dict.hero.dayTitle : dict.hero.nightTitle}
                </p>
                <p className="mt-1.5 text-[0.8125rem] leading-relaxed text-white/80 sm:text-sm">
                  {isDay ? dict.hero.dayText : dict.hero.nightText}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 divide-x divide-white/8 px-1 pt-3">
              {[
                { icon: "bolt" as const, label: dict.trust[2].title },
                { icon: "truck" as const, label: dict.common.freeDelivery },
                { icon: "shield" as const, label: dict.common.guarantee },
              ].map((item) => (
                <div
                  key={item.label}
                  className="flex flex-col items-center gap-1.5 px-2 pb-2.5 text-center"
                >
                  <Icon name={item.icon} className="h-4 w-4 text-[var(--color-brand)]" />
                  <span className="text-[0.625rem] leading-tight text-white/55">
                    {item.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <p className="mt-3 flex items-start gap-2 px-1 text-[0.6875rem] leading-relaxed text-white/35">
            <Icon name="moon" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            {dict.hero.note}
          </p>
        </div>
      </div>
    </section>
  );
}
