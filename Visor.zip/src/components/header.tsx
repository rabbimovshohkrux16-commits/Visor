"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Logo, Icon } from "./icons";
import { localeLabels, localeShort } from "@/i18n";
import { LOCALES, type Locale } from "@/lib/constants";
import type { Dictionary } from "@/i18n";

function setLocaleCookie(next: Locale) {
  document.cookie = `dw_locale=${next}; path=/; max-age=31536000; samesite=lax`;
}

export function Header({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const pathname = usePathname();
  const [menu, setMenu] = useState({ pathname, open: false });
  const open = menu.pathname === pathname && menu.open;
  const closeMenu = () => setMenu({ pathname, open: false });
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const rest = pathname.replace(/^\/(uz|ru|en)/, "");
  const links = [
    { href: `/${locale}#lenses`, label: dict.nav.lenses },
    { href: `/${locale}#how`, label: dict.nav.how },
    { href: `/${locale}#reviews`, label: dict.nav.reviews },
    { href: `/${locale}#faq`, label: dict.nav.faq },
    { href: `/${locale}/track`, label: dict.nav.track },
  ];

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
        scrolled || open
          ? "border-b border-white/10 bg-[#070a0f]/90 backdrop-blur-xl"
          : "border-b border-transparent bg-gradient-to-b from-[#070a0f]/80 to-transparent"
      }`}
    >
      <div className="container-page flex h-16 items-center justify-between gap-3 md:h-[72px]">
        <Link href={`/${locale}`} aria-label="Carstore_sam" onClick={() => closeMenu()}>
          <Logo />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-full px-3.5 py-2 text-[0.8125rem] font-medium text-white/65 transition hover:bg-white/5 hover:text-white"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <div className="hidden items-center rounded-full border border-white/10 bg-white/[0.04] p-1 sm:flex">
            {LOCALES.map((code) => (
              <Link
                key={code}
                href={`/${code}${rest}`}
                onClick={() => setLocaleCookie(code)}
                aria-label={localeLabels[code]}
                className={`rounded-full px-2.5 py-1 text-[0.6875rem] font-bold tracking-wide transition ${
                  code === locale
                    ? "bg-[var(--color-brand)] text-[#16110a]"
                    : "text-white/60 hover:text-white"
                }`}
              >
                {localeShort[code]}
              </Link>
            ))}
          </div>

          <Link
            href={`/${locale}#order`}
            className="btn btn-primary hidden !px-5 !py-2.5 !text-[0.8125rem] md:inline-flex"
          >
            {dict.nav.order}
            <Icon name="arrow" className="h-4 w-4" />
          </Link>

          <button
            type="button"
            onClick={() => setMenu({ pathname, open: !open })}
            aria-expanded={open}
            aria-label="Menu"
            className="grid h-10 w-10 place-items-center rounded-full border border-white/12 bg-white/5 text-white lg:hidden"
          >
            <Icon name={open ? "close" : "menu"} className="h-5 w-5" />
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-white/10 bg-[#070a0f]/97 backdrop-blur-xl lg:hidden">
          <div className="container-page space-y-1 py-4">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => closeMenu()}
                className="flex items-center justify-between rounded-xl px-3 py-3 text-sm font-medium text-white/80 transition hover:bg-white/5"
              >
                {link.label}
                <Icon name="arrow" className="h-4 w-4 text-white/30" />
              </Link>
            ))}
            <div className="flex items-center gap-2 px-3 pt-3">
              {LOCALES.map((code) => (
                <Link
                  key={code}
                  href={`/${code}${rest}`}
                  onClick={() => {
                    setLocaleCookie(code);
                    closeMenu();
                  }}
                  className={`rounded-full px-3 py-1.5 text-xs font-semibold ${
                    code === locale
                      ? "bg-[var(--color-brand)] text-[#16110a]"
                      : "border border-white/12 text-white/70"
                  }`}
                >
                  {localeLabels[code]}
                </Link>
              ))}
            </div>
            <div className="px-3 pt-3">
              <Link
                href={`/${locale}#order`}
                onClick={() => closeMenu()}
                className="btn btn-primary w-full"
              >
                {dict.common.orderNow}
                <Icon name="arrow" className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
