"use client";

import { useState } from "react";
import type { Dictionary } from "@/i18n";
import { Icon } from "./icons";

export function FaqAccordion({ items }: { items: Dictionary["faq"]["items"] }) {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="divide-y divide-white/8 overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
      {items.map((item, index) => {
        const isOpen = open === index;
        return (
          <div key={item.q}>
            <button
              type="button"
              onClick={() => setOpen(isOpen ? null : index)}
              aria-expanded={isOpen}
              className="flex w-full items-center justify-between gap-4 px-4 py-4 text-left transition hover:bg-white/[0.03] sm:px-5 sm:py-5"
            >
              <span className="text-[0.9125rem] font-semibold leading-snug text-white/90">
                {item.q}
              </span>
              <span
                className={`grid h-7 w-7 shrink-0 place-items-center rounded-full border transition ${
                  isOpen
                    ? "border-[var(--color-brand)]/60 bg-[var(--color-brand)]/15 text-[var(--color-brand)]"
                    : "border-white/15 text-white/50"
                }`}
              >
                <Icon name={isOpen ? "minus" : "plus"} className="h-3.5 w-3.5" />
              </span>
            </button>
            <div
              className={`grid transition-all duration-300 ease-out ${
                isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
              }`}
            >
              <div className="overflow-hidden">
                <p className="px-4 pb-5 pr-12 text-sm leading-relaxed text-white/55 sm:px-5">
                  {item.a}
                </p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
