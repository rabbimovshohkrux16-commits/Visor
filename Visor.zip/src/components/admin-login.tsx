"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import type { Dictionary } from "@/i18n";
import type { Locale } from "@/lib/constants";
import { Icon, Logo } from "./icons";

export function AdminLogin({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<"invalid" | "not_configured" | null>(null);
  const [loading, setLoading] = useState(false);

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-16">
      <div className="w-full max-w-sm">
        <div className="flex justify-center">
          <Logo />
        </div>
        <div className="card mt-6 p-6">
          <h1 className="text-xl font-bold text-white">{dict.admin.title}</h1>
          <p className="mt-1.5 text-xs text-white/45">{dict.admin.loginHint}</p>
          <form
            onSubmit={async (event) => {
              event.preventDefault();
              setLoading(true);
              setError(null);
              try {
                const response = await fetch("/api/admin/login", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ password }),
                });
                if (!response.ok) {
                  const data = (await response.json()) as { error?: string };
                  setError(data.error === "not_configured" ? "not_configured" : "invalid");
                  setLoading(false);
                  return;
                }
                router.refresh();
              } catch {
                setError("invalid");
                setLoading(false);
              }
            }}
            className="mt-5 space-y-3"
          >
            <div>
              <label htmlFor="password" className="field-label">
                {dict.admin.password}
              </label>
              <input
                id="password"
                type="password"
                className="field"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                autoComplete="current-password"
                aria-invalid={error === "invalid"}
              />
            </div>
            {error && (
              <p className="text-xs text-red-400">
                {error === "not_configured" ? dict.admin.adminNotConfigured : dict.admin.wrongPassword}
              </p>
            )}
            <button type="submit" disabled={loading} className="btn btn-primary w-full">
              {dict.admin.loginBtn}
              <Icon name="arrow" className="h-4 w-4" />
            </button>
          </form>
        </div>
        <p className="mt-4 text-center text-xs text-white/35">
          <Link href={`/${locale}`} className="hover:text-white">
            ← {dict.common.backHome}
          </Link>
        </p>
      </div>
    </div>
  );
}
