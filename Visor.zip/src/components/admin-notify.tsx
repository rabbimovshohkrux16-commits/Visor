"use client";

import { useEffect, useState } from "react";
import type { Dictionary } from "@/i18n";
import { CONTACTS } from "@/lib/constants";
import { Icon } from "./icons";

type Status = {
  telegram: {
    connected: boolean;
    fromEnv: boolean;
    tokenMasked: string;
    hasToken: boolean;
    chatLabel: string;
  };
  email: {
    connected: boolean;
    fromEnv: boolean;
    host: string;
    port: string;
    user: string;
    hasPass: boolean;
    to: string;
  };
};

type Flash = { kind: "ok" | "error"; text: string } | null;

function Badge({ on, env, t }: { on: boolean; env: boolean; t: Dictionary["admin"]["notify"] }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[0.625rem] font-semibold ${
        on
          ? "border-[var(--color-mint)]/40 bg-[var(--color-mint)]/10 text-[var(--color-mint)]"
          : "border-white/15 text-white/45"
      }`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${on ? "bg-[var(--color-mint)]" : "bg-white/30"}`} />
      {on ? (env ? t.envManaged : t.connected) : t.notConnected}
    </span>
  );
}

function FlashLine({ flash }: { flash: Flash }) {
  return flash ? (
      <p
        className={`mt-2 text-xs ${flash.kind === "ok" ? "text-[var(--color-mint)]" : "text-red-400"}`}
      >
        {flash.text}
      </p>
    ) : null;
}


export function AdminNotify({ dict }: { dict: Dictionary }) {
  const t = dict.admin.notify;
  const [open, setOpen] = useState(false);
  const [status, setStatus] = useState<Status | null>(null);
  const [token, setToken] = useState("");
  const [email, setEmail] = useState({ host: "smtp.gmail.com", port: "465", user: CONTACTS.email, pass: "", to: CONTACTS.email });
  const [busy, setBusy] = useState<string | null>(null);
  const [tgFlash, setTgFlash] = useState<Flash>(null);
  const [mailFlash, setMailFlash] = useState<Flash>(null);

  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/admin/settings", { signal: controller.signal })
      .then((response) => response.ok ? response.json() as Promise<Status> : null)
      .then((data) => {
        if (!data || controller.signal.aborted) return;
        setStatus(data);
        setEmail((prev) => ({
          ...prev,
          host: data.email.host,
          port: data.email.port,
          user: data.email.user,
          to: data.email.to,
        }));
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted) console.error("Could not load notification settings", error);
      });
    return () => controller.abort();
  }, []);

  const act = async (
    action: string,
    payload: Record<string, string>,
    setFlash: (flash: Flash) => void,
    okText: string,
  ) => {
    setBusy(action);
    setFlash(null);
    try {
      const response = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, ...payload }),
      });
      const data = (await response.json()) as Partial<Status> & { ok?: boolean; error?: string };
      if (!response.ok || !data.ok) {
        setFlash({ kind: "error", text: data.error === "no_chat" ? t.noChat : t.errorGeneric });
      } else {
        setFlash({ kind: "ok", text: okText });
        if (data.telegram && data.email) setStatus(data as Status);
        if (action === "save_telegram") setToken("");
        if (action === "save_email") setEmail((prev) => ({ ...prev, pass: "" }));
      }
    } catch {
      setFlash({ kind: "error", text: t.errorGeneric });
    } finally {
      setBusy(null);
    }
  };

  return (
    <section className="card mt-6 overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
      >
        <div className="flex items-center gap-3">
          <span className="grid h-9 w-9 place-items-center rounded-xl border border-[var(--color-brand)]/30 bg-[var(--color-brand)]/10 text-[var(--color-brand)]">
            <Icon name="telegram" className="h-4 w-4" />
          </span>
          <div>
            <p className="text-sm font-bold text-white">{t.title}</p>
            <p className="text-[0.6875rem] text-white/45">{t.subtitle}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {status && (
            <>
              <span className="hidden sm:inline-flex">
                <Badge on={status.telegram.connected} env={status.telegram.fromEnv} t={t} />
              </span>
              <span className="hidden sm:inline-flex">
                <Badge on={status.email.connected} env={status.email.fromEnv} t={t} />
              </span>
            </>
          )}
          <Icon name={open ? "minus" : "plus"} className="h-4 w-4 text-white/50" />
        </div>
      </button>

      {open && (
        <div className="grid gap-5 border-t border-white/8 p-5 lg:grid-cols-2">
          {/* Telegram */}
          <div className="rounded-2xl border border-white/8 bg-black/20 p-4">
            <div className="flex items-center justify-between gap-3">
              <h3 className="text-sm font-bold text-white">{t.telegramTitle}</h3>
              {status && <Badge on={status.telegram.connected} env={status.telegram.fromEnv} t={t} />}
            </div>
            <ol className="mt-3 space-y-1.5 text-[0.75rem] text-white/55">
              {t.telegramSteps.map((step, index) => (
                <li key={step} className="flex gap-2">
                  <span className="text-[var(--color-brand)]">{index + 1}.</span>
                  {step}
                </li>
              ))}
            </ol>
            <div className="mt-4">
              <label className="field-label" htmlFor="tg-token">
                {t.tokenLabel}
              </label>
              <div className="flex flex-col gap-2 sm:flex-row">
                <input
                  id="tg-token"
                  className="field flex-1 font-mono text-xs"
                  placeholder={status?.telegram.tokenMasked || "123456789:AAH..."}
                  value={token}
                  onChange={(event) => setToken(event.target.value)}
                  autoComplete="off"
                />
                <button
                  type="button"
                  disabled={busy !== null || !token.trim()}
                  onClick={() => act("save_telegram", { token }, setTgFlash, t.saved)}
                  className="btn btn-ghost shrink-0 !py-2.5 !text-xs"
                >
                  {t.save}
                </button>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={busy !== null || !status?.telegram.hasToken}
                onClick={() => act("connect_telegram", {}, setTgFlash, t.connected)}
                className="btn btn-primary !py-2.5 !text-xs"
              >
                <Icon name="bolt" className="h-3.5 w-3.5" />
                {t.connect}
              </button>
              {status?.telegram.connected && (
                <>
                  <button
                    type="button"
                    disabled={busy !== null}
                    onClick={() => act("test_telegram", {}, setTgFlash, t.testSent)}
                    className="btn btn-ghost !py-2.5 !text-xs"
                  >
                    {t.test}
                  </button>
                  {status.telegram.chatLabel && (
                    <span className="text-[0.6875rem] text-white/45">
                      {t.chatLabel}: {status.telegram.chatLabel}
                    </span>
                  )}
                </>
              )}
            </div>
            <FlashLine flash={tgFlash} />
          </div>

          {/* Email */}
          <div className="rounded-2xl border border-white/8 bg-black/20 p-4">
            <div className="flex items-center justify-between gap-3">
              <h3 className="text-sm font-bold text-white">{t.emailTitle}</h3>
              {status && <Badge on={status.email.connected} env={status.email.fromEnv} t={t} />}
            </div>
            <p className="mt-2 text-[0.75rem] leading-relaxed text-white/55">{t.emailHint}</p>
            <div className="mt-3 grid gap-3 sm:grid-cols-[1fr_90px]">
              <div>
                <label className="field-label" htmlFor="smtp-host">
                  {t.smtpHost}
                </label>
                <input
                  id="smtp-host"
                  className="field"
                  value={email.host}
                  onChange={(event) => setEmail({ ...email, host: event.target.value })}
                />
              </div>
              <div>
                <label className="field-label" htmlFor="smtp-port">
                  {t.smtpPort}
                </label>
                <input
                  id="smtp-port"
                  className="field"
                  inputMode="numeric"
                  value={email.port}
                  onChange={(event) => setEmail({ ...email, port: event.target.value })}
                />
              </div>
            </div>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <div>
                <label className="field-label" htmlFor="smtp-user">
                  {t.smtpUser}
                </label>
                <input
                  id="smtp-user"
                  className="field"
                  autoComplete="off"
                  value={email.user}
                  onChange={(event) => setEmail({ ...email, user: event.target.value })}
                />
              </div>
              <div>
                <label className="field-label" htmlFor="smtp-pass">
                  {t.smtpPass}
                </label>
                <input
                  id="smtp-pass"
                  type="password"
                  className="field"
                  autoComplete="new-password"
                  placeholder={status?.email.hasPass ? "••••••••" : ""}
                  value={email.pass}
                  onChange={(event) => setEmail({ ...email, pass: event.target.value })}
                />
              </div>
            </div>
            <div className="mt-3">
              <label className="field-label" htmlFor="notify-to">
                {t.notifyEmail}
              </label>
              <input
                id="notify-to"
                className="field"
                value={email.to}
                onChange={(event) => setEmail({ ...email, to: event.target.value })}
              />
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                disabled={busy !== null}
                onClick={() => act("save_email", email, setMailFlash, t.saved)}
                className="btn btn-primary !py-2.5 !text-xs"
              >
                {t.save}
              </button>
              <button
                type="button"
                disabled={busy !== null || !status?.email.connected}
                onClick={() => act("test_email", {}, setMailFlash, t.testSent)}
                className="btn btn-ghost !py-2.5 !text-xs"
              >
                {t.test}
              </button>
            </div>
            <FlashLine flash={mailFlash} />
          </div>

          <p className="text-[0.6875rem] leading-relaxed text-white/35 lg:col-span-2">
            {t.alwaysAdmin} {t.smsNote}
          </p>
        </div>
      )}
    </section>
  );
}
