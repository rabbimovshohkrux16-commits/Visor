"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import type { Dictionary } from "@/i18n";
import type { Locale } from "@/lib/constants";
import { ORDER_STATUSES } from "@/lib/constants";
import { formatDate, formatPrice, prettyPhone } from "@/lib/format";
import { Icon, Logo } from "./icons";
import { AdminNotify } from "./admin-notify";

export type AdminOrder = {
  id: number;
  code: string;
  customerName: string;
  phone: string;
  region: string;
  city: string;
  address: string;
  bundleCode: string;
  qty: number;
  total: number;
  status: string;
  deliveryMethod: string;
  comment: string | null;
  source: string | null;
  createdAt: string;
};

const statusStyles: Record<string, string> = {
  new: "border-[var(--color-brand)]/40 bg-[var(--color-brand)]/12 text-[var(--color-brand)]",
  confirmed: "border-sky-400/40 bg-sky-400/10 text-sky-300",
  shipped: "border-violet-400/40 bg-violet-400/10 text-violet-300",
  delivered: "border-[var(--color-mint)]/40 bg-[var(--color-mint)]/10 text-[var(--color-mint)]",
  cancelled: "border-red-400/40 bg-red-400/10 text-red-300",
};

export function AdminOrders({
  locale,
  dict,
  orders,
  stats,
}: {
  locale: Locale;
  dict: Dictionary;
  orders: AdminOrder[];
  stats: { total: number; new: number; delivered: number; revenue: number };
}) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [savingId, setSavingId] = useState<number | null>(null);
  const [savedId, setSavedId] = useState<number | null>(null);
  const [statusErrorId, setStatusErrorId] = useState<number | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return orders.filter((order) => {
      const matchesQuery =
        !q ||
        order.customerName.toLowerCase().includes(q) ||
        order.phone.includes(q) ||
        order.code.toLowerCase().includes(q) ||
        order.city.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "all" || order.status === statusFilter;
      return matchesQuery && matchesStatus;
    });
  }, [orders, query, statusFilter]);

  const updateStatus = async (id: number, status: string) => {
    setSavingId(id);
    setStatusErrorId(null);
    try {
      const response = await fetch(`/api/admin/orders/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!response.ok) throw new Error("Status update failed");
      setSavedId(id);
      router.refresh();
      setTimeout(() => setSavedId((current) => (current === id ? null : current)), 2000);
    } catch {
      setStatusErrorId(id);
    } finally {
      setSavingId(null);
    }
  };

  const logout = async () => {
    await fetch("/api/admin/login", { method: "DELETE" });
    router.refresh();
  };

  const statCards = [
    { label: dict.admin.totalOrders, value: stats.total, icon: "package" as const },
    { label: dict.admin.newOrders, value: stats.new, icon: "bolt" as const },
    { label: dict.admin.delivered, value: stats.delivered, icon: "check" as const },
    { label: dict.admin.revenue, value: formatPrice(stats.revenue, locale), icon: "card" as const },
  ];

  return (
    <div className="min-h-screen bg-[var(--color-ink)]">
      <header className="border-b border-white/10 bg-[#070a0f]/90 backdrop-blur">
        <div className="container-page flex h-16 items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Logo />
            <span className="hidden rounded-full border border-white/10 px-2.5 py-1 text-[0.625rem] uppercase tracking-[0.14em] text-white/45 sm:inline">
              Admin
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Link
              href={`/${locale}`}
              className="rounded-full border border-white/12 px-3 py-1.5 text-xs text-white/65 hover:text-white"
            >
              {dict.common.backHome}
            </Link>
            <button
              type="button"
              onClick={logout}
              className="rounded-full border border-white/12 px-3 py-1.5 text-xs text-white/65 hover:border-red-400/40 hover:text-red-300"
            >
              {dict.admin.logout}
            </button>
          </div>
        </div>
      </header>

      <div className="container-page py-8">
        <h1 className="text-2xl font-extrabold">{dict.admin.title}</h1>
        <p className="mt-1 text-sm text-white/45">{dict.admin.subtitle}</p>

        <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {statCards.map((card) => (
            <div key={card.label} className="card p-4">
              <div className="flex items-center justify-between">
                <p className="text-[0.6875rem] uppercase tracking-[0.12em] text-white/40">
                  {card.label}
                </p>
                <Icon name={card.icon} className="h-4 w-4 text-[var(--color-brand)]" />
              </div>
              <p className="mt-2 text-xl font-extrabold text-white sm:text-2xl">{card.value}</p>
            </div>
          ))}
        </div>

        <AdminNotify dict={dict} />

        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Icon
              name="search"
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/35"
            />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={dict.admin.search}
              className="field !pl-9"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(event) => setStatusFilter(event.target.value)}
            className="field appearance-none sm:!w-52"
          >
            <option value="all" className="bg-[#11161f]">
              {dict.admin.allStatuses}
            </option>
            {ORDER_STATUSES.map((status) => (
              <option key={status} value={status} className="bg-[#11161f]">
                {dict.order.statuses[status]}
              </option>
            ))}
          </select>
        </div>

        {filtered.length === 0 ? (
          <div className="card mt-6 p-8 text-center text-sm text-white/45">{dict.admin.empty}</div>
        ) : (
          <>
            {/* desktop table */}
            <div className="card mt-4 hidden overflow-hidden lg:block">
              <table className="w-full text-left text-sm">
                <thead className="border-b border-white/10 bg-white/[0.03] text-[0.625rem] uppercase tracking-[0.12em] text-white/40">
                  <tr>
                    <th className="px-4 py-3">{dict.admin.name}</th>
                    <th className="px-4 py-3">{dict.admin.amount}</th>
                    <th className="px-4 py-3">{dict.admin.address}</th>
                    <th className="px-4 py-3">{dict.admin.date}</th>
                    <th className="px-4 py-3">{dict.admin.status}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/6">
                  {filtered.map((order) => (
                    <tr key={order.id} className="align-top hover:bg-white/[0.02]">
                      <td className="px-4 py-3">
                        <p className="font-semibold text-white">{order.customerName}</p>
                        <a href={`tel:${order.phone}`} className="text-xs text-white/50 hover:text-white">
                          {prettyPhone(order.phone)}
                        </a>
                        <div className="mt-1 flex flex-wrap items-center gap-1.5">
                          <span className="rounded bg-white/8 px-1.5 py-0.5 text-[0.625rem] font-mono text-white/60">
                            {order.code}
                          </span>
                          {order.source && (
                            <span className="rounded bg-[var(--color-brand)]/12 px-1.5 py-0.5 text-[0.5625rem] text-[var(--color-brand)]">
                              {order.source}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <p className="font-bold text-white">{formatPrice(order.total, locale)}</p>
                        <p className="text-xs text-white/45">
                          {order.qty} × {order.bundleCode}
                        </p>
                      </td>
                      <td className="max-w-[220px] px-4 py-3">
                        <p className="text-xs text-white/70">
                          {order.city}, {order.region}
                        </p>
                        <p className="mt-0.5 text-[0.6875rem] text-white/40">{order.address}</p>
                        {order.comment && (
                          <p className="mt-1 rounded bg-white/5 px-1.5 py-0.5 text-[0.625rem] text-white/50">
                            {order.comment}
                          </p>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-white/50">
                        {formatDate(order.createdAt, locale)}
                      </td>
                      <td className="px-4 py-3">
                        <select
                          value={order.status}
                          disabled={savingId === order.id}
                          onChange={(event) => updateStatus(order.id, event.target.value)}
                          className={`rounded-lg border px-2 py-1.5 text-xs font-semibold ${
                            statusStyles[order.status] ?? "border-white/15 text-white"
                          }`}
                        >
                          {ORDER_STATUSES.map((status) => (
                            <option key={status} value={status} className="bg-[#11161f] text-white">
                              {dict.order.statuses[status]}
                            </option>
                          ))}
                        </select>
                        {savedId === order.id && (
                          <span className="mt-1 block text-[0.625rem] text-[var(--color-mint)]">
                            {dict.admin.saved}
                          </span>
                        )}
                        {statusErrorId === order.id && (
                          <span role="alert" className="mt-1 block text-[0.625rem] text-red-400">
                            {dict.admin.updateFailed}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* mobile cards */}
            <div className="mt-4 space-y-3 lg:hidden">
              {filtered.map((order) => (
                <div key={order.id} className="card p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-white">{order.customerName}</p>
                      <a href={`tel:${order.phone}`} className="text-xs text-white/50">
                        {prettyPhone(order.phone)}
                      </a>
                    </div>
                    <span className="rounded bg-white/8 px-1.5 py-0.5 text-[0.625rem] font-mono text-white/60">
                      {order.code}
                    </span>
                  </div>
                  <p className="mt-2 text-xs text-white/55">
                    {order.city}, {order.region} · {order.address}
                  </p>
                  <div className="mt-2 flex items-center justify-between gap-2">
                    <span className="text-sm font-bold text-white">{formatPrice(order.total, locale)}</span>
                    <span className="text-[0.6875rem] text-white/40">
                      {formatDate(order.createdAt, locale)}
                    </span>
                  </div>
                  <select
                    value={order.status}
                    disabled={savingId === order.id}
                    onChange={(event) => updateStatus(order.id, event.target.value)}
                    className={`mt-3 w-full rounded-lg border px-2 py-2 text-xs font-semibold ${
                      statusStyles[order.status] ?? "border-white/15 text-white"
                    }`}
                  >
                    {ORDER_STATUSES.map((status) => (
                      <option key={status} value={status} className="bg-[#11161f] text-white">
                        {dict.order.statuses[status]}
                      </option>
                    ))}
                  </select>
                  {statusErrorId === order.id && (
                    <p role="alert" className="mt-1 text-xs text-red-400">{dict.admin.updateFailed}</p>
                  )}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
