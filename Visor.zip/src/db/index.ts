import { attachDatabasePool } from "@vercel/functions";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * Create the database client only when a request actually needs PostgreSQL.
 * Next.js imports route modules while building, when runtime secrets may not
 * exist yet. An absent DATABASE_URL must never be replaced with a dummy URL.
 */
function createDatabase(connectionString: string) {
  // pg supports SCRAM channel binding even though older @types/pg omit it.
  // Passing the options as a variable keeps the runtime option intact.
  const options = {
    connectionString,
    enableChannelBinding: true,
    // Neon recommends its pooled endpoint and a small client pool for serverless.
    max: 2,
    idleTimeoutMillis: 5_000,
    connectionTimeoutMillis: 15_000,
    allowExitOnIdle: true,
  };
  const pool = new Pool(options);

  pool.on("error", (error) => {
    console.error("Unexpected idle PostgreSQL connection error:", error.message);
  });

  // Close idle connections before a Vercel Fluid Compute instance suspends.
  if (process.env.VERCEL === "1") {
    attachDatabasePool(pool);
  }

  return { pool, client: drizzle(pool), connectionString };
}

type DatabaseState = ReturnType<typeof createDatabase>;
const globalForDb = globalThis as typeof globalThis & {
  __carstoreDatabase?: DatabaseState;
};

export function getDb(): DatabaseState["client"] {
  const connectionString = process.env.DATABASE_URL?.trim();
  if (!connectionString) {
    throw new Error(
      "DATABASE_URL is not configured. Set a PostgreSQL connection string in the runtime environment.",
    );
  }

  try {
    const url = new URL(connectionString);
    if (url.protocol !== "postgres:" && url.protocol !== "postgresql:") {
      throw new Error("Unsupported protocol");
    }
  } catch {
    throw new Error("DATABASE_URL must be a valid PostgreSQL connection string.");
  }

  const previous = globalForDb.__carstoreDatabase;
  if (!previous || previous.connectionString !== connectionString) {
    if (previous) {
      void previous.pool.end().catch((error: Error) => {
        console.error("Could not close previous PostgreSQL pool:", error.message);
      });
    }
    globalForDb.__carstoreDatabase = createDatabase(connectionString);
  }

  return globalForDb.__carstoreDatabase!.client;
}
