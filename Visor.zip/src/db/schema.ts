import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const bundles = pgTable("bundles", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  qty: integer("qty").notNull(),
  price: integer("price").notNull(),
  compareAt: integer("compare_at").notNull(),
  badge: varchar("badge", { length: 32 }),
  sortOrder: integer("sort_order").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 24 }).notNull().unique(),
  locale: varchar("locale", { length: 4 }).notNull().default("ru"),
  bundleCode: varchar("bundle_code", { length: 32 }).notNull(),
  qty: integer("qty").notNull(),
  unitPrice: integer("unit_price").notNull(),
  total: integer("total").notNull(),
  deliveryFee: integer("delivery_fee").notNull().default(0),
  currency: varchar("currency", { length: 8 }).notNull().default("UZS"),
  customerName: varchar("customer_name", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 32 }).notNull(),
  region: varchar("region", { length: 64 }).notNull(),
  city: varchar("city", { length: 96 }).notNull(),
  address: text("address").notNull(),
  comment: text("comment"),
  deliveryMethod: varchar("delivery_method", { length: 24 }).notNull().default("courier"),
  paymentMethod: varchar("payment_method", { length: 24 }).notNull().default("card_on_delivery"),
  source: varchar("source", { length: 120 }),
  status: varchar("status", { length: 24 }).notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  locale: varchar("locale", { length: 4 }).notNull(),
  name: varchar("name", { length: 80 }).notNull(),
  city: varchar("city", { length: 80 }).notNull(),
  rating: integer("rating").notNull().default(5),
  body: text("body").notNull(),
  car: varchar("car", { length: 80 }),
  visible: boolean("visible").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const settings = pgTable("settings", {
  key: varchar("key", { length: 64 }).primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Bundle = typeof bundles.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Review = typeof reviews.$inferSelect;
