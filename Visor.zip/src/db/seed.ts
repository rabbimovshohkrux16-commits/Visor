import { getDb } from "@/db";
import { bundles } from "@/db/schema";
import { DEFAULT_BUNDLES } from "@/lib/bundles-data";

// These are the store's existing catalogue prices, not sample orders or reviews.
// Existing products are never overwritten when the application starts.
let seedPromise: Promise<void> | null = null;

async function runSeed(): Promise<void> {
  const database = getDb();
  const existing = await database.select({ id: bundles.id }).from(bundles).limit(1);
  if (existing.length > 0) return;

  await database
    .insert(bundles)
    .values(
      DEFAULT_BUNDLES.map((bundle) => ({
        code: bundle.code,
        qty: bundle.qty,
        price: bundle.price,
        compareAt: bundle.compareAt,
        badge: bundle.badge,
        sortOrder: bundle.sortOrder,
      })),
    )
    .onConflictDoNothing({ target: bundles.code });
}

export function ensureSeed(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error: unknown) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}
