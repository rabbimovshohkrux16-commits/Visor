import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { CONTACTS, isLocale } from "@/lib/constants";
import { getDictionary } from "@/i18n";
import { getOrderByCode } from "@/lib/orders";
import { formatDate, formatPrice, prettyPhone } from "@/lib/format";
import { SiteShell } from "@/components/site-shell";
import { Icon } from "@/components/icons";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  robots: { index: false, follow: false },
};

const FLOW = ["new", "confirmed", "shipped", "delivered"] as const;

export default async function OrderConfirmationPage({
  params,
}: {
  params: Promise<{ locale: string; code: string }>;
}) {
  const { locale, code } = await params;
  if (!isLocale(locale)) notFound();
  const dict = getDictionary(locale);
  const order = await getOrderByCode(code);
  if (!order) notFound();

  const bundleCopy = dict.offer.bundles[order.bundleCode as keyof typeof dict.offer.bundles];
  const statusLabel = dict.order.statuses[order.status as keyof typeof dict.order.statuses];
  const stepIndex = FLOW.indexOf(order.status as (typeof FLOW)[number]);
  const cancelled = order.status === "cancelled";
  const isPickup = order.deliveryMethod === "pickup";

  const telegramText = [
    `${dict.order.codeLabel}: ${order.code}`,
    `${dict.form.name}: ${order.customerName}`,
    `${dict.form.phone}: ${prettyPhone(order.phone)}`,
    `${dict.form.product}: ${order.qty} × ${dict.form.productName}`,
    `${dict.form.total}: ${formatPrice(order.total, locale)}`,
    isPickup
      ? `${dict.form.delivery}: ${dict.order.pickup}`
      : `${dict.order.deliveryTo}: ${order.city}, ${order.region}, ${order.address}`,
    order.comment ? `${dict.order.commentLabel}: ${order.comment}` : null,
  ]
    .filter(Boolean)
    .join("\n");
  const telegramShareHref = `https://t.me/${CONTACTS.telegramUser}?text=${encodeURIComponent(telegramText)}`;

  return (
    <SiteShell locale={locale} dict={dict}>
      <div className="container-page py-10 md:py-16">
        <div className="grid gap-6 lg:grid-cols-[1.35fr_0.8fr]">
          <div className="card relative overflow-hidden p-6 sm:p-8">
            <div className="pointer-events-none absolute -right-16 -top-20 h-52 w-52 rounded-full bg-[var(--color-mint)]/10 blur-3xl" />
            <div className="relative">
              <span className="grid h-12 w-12 place-items-center rounded-full border border-[var(--color-mint)]/30 bg-[var(--color-mint)]/12 text-[var(--color-mint)]">
                <Icon name="check" className="h-6 w-6" strokeWidth={2.4} />
              </span>
              <p className="mt-4 text-[0.6875rem] font-semibold uppercase tracking-[0.18em] text-[var(--color-brand)]">
                {dict.order.eyebrow}
              </p>
              <h1 className="mt-2 text-2xl font-extrabold sm:text-3xl">
                {dict.order.title}, {order.customerName.split(" ")[0]}!
              </h1>
              <p className="mt-2 max-w-lg text-sm leading-relaxed text-white/55">
                {dict.order.text}
              </p>

              <div className="mt-6 flex flex-wrap items-center gap-3">
                <div className="rounded-xl border border-white/12 bg-black/30 px-4 py-2.5">
                  <p className="text-[0.625rem] uppercase tracking-[0.14em] text-white/40">
                    {dict.order.codeLabel}
                  </p>
                  <p className="text-base font-extrabold tracking-wide text-white">{order.code}</p>
                </div>
                <div className="rounded-xl border border-white/12 bg-black/30 px-4 py-2.5">
                  <p className="text-[0.625rem] uppercase tracking-[0.14em] text-white/40">
                    {dict.order.statusLabel}
                  </p>
                  <p
                    className={`text-sm font-bold ${
                      cancelled ? "text-red-400" : "text-[var(--color-brand)]"
                    }`}
                  >
                    {statusLabel}
                  </p>
                </div>
                <div className="rounded-xl border border-white/12 bg-black/30 px-4 py-2.5">
                  <p className="text-[0.625rem] uppercase tracking-[0.14em] text-white/40">
                    {dict.form.total}
                  </p>
                  <p className="text-sm font-bold text-white">
                    {formatPrice(order.total, locale)}
                  </p>
                </div>
              </div>

              {!cancelled && (
                <div className="mt-7">
                  <div className="flex items-center">
                    {dict.order.timeline.map((step, index) => {
                      const active = index <= stepIndex;
                      return (
                        <div key={step} className="flex flex-1 items-center last:flex-none">
                          <div className="flex flex-col items-center gap-1.5">
                            <span
                              className={`grid h-7 w-7 place-items-center rounded-full border text-[0.625rem] font-bold ${
                                active
                                  ? "border-[var(--color-brand)] bg-[var(--color-brand)] text-[#16110a]"
                                  : "border-white/15 text-white/40"
                              }`}
                            >
                              {active ? <Icon name="check" className="h-3.5 w-3.5" /> : index + 1}
                            </span>
                            <span
                              className={`max-w-[72px] text-center text-[0.5625rem] leading-tight ${
                                active ? "text-white/80" : "text-white/35"
                              }`}
                            >
                              {step}
                            </span>
                          </div>
                          {index < dict.order.timeline.length - 1 && (
                            <span
                              className={`mx-1 mb-4 h-px flex-1 ${
                                index < stepIndex ? "bg-[var(--color-brand)]/60" : "bg-white/12"
                              }`}
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="mt-7 rounded-2xl border border-white/8 bg-white/[0.02] p-4">
                <h2 className="text-[0.6875rem] font-semibold uppercase tracking-[0.18em] text-white/40">
                  {dict.order.detailsTitle}
                </h2>
                <dl className="mt-3 divide-y divide-white/8 text-sm">
                  <div className="flex items-center justify-between gap-4 py-2.5">
                    <dt className="text-white/45">{dict.form.product}</dt>
                    <dd className="text-right font-medium text-white">
                      {bundleCopy?.name ?? `${order.qty} × Carstore_sam`}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-4 py-2.5">
                    <dt className="text-white/45">{dict.order.qty}</dt>
                    <dd className="text-right font-medium text-white">
                      {order.qty} {dict.common.each}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-4 py-2.5">
                    <dt className="text-white/45">{dict.form.deliveryPrice}</dt>
                    <dd className="text-right font-medium text-[var(--color-brand)]">
                      {dict.form.deliveryValue}
                    </dd>
                  </div>
                  <div className="flex items-start justify-between gap-4 py-2.5">
                    <dt className="text-white/45">
                      {isPickup ? dict.form.delivery : dict.order.deliveryTo}
                    </dt>
                    <dd className="text-right font-medium text-white">
                      {isPickup ? dict.order.pickup : `${order.city}, ${order.region}`}
                      {!isPickup && (
                        <>
                          <br />
                          <span className="text-white/55">{order.address}</span>
                        </>
                      )}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-4 py-2.5">
                    <dt className="text-white/45">{dict.order.paymentLabel}</dt>
                    <dd className="text-right font-medium text-white">{dict.order.paymentCod}</dd>
                  </div>
                  <div className="flex items-center justify-between gap-4 py-2.5">
                    <dt className="text-white/45">{dict.admin.date}</dt>
                    <dd className="text-right text-white/70">{formatDate(order.createdAt, locale)}</dd>
                  </div>
                  {order.comment && (
                    <div className="flex items-start justify-between gap-4 py-2.5">
                      <dt className="text-white/45">{dict.order.commentLabel}</dt>
                      <dd className="text-right text-white/70">{order.comment}</dd>
                    </div>
                  )}
                </dl>
              </div>

              <div className="mt-6 rounded-2xl border border-[var(--color-brand)]/30 bg-[var(--color-brand)]/[0.07] p-4">
                <p className="text-[0.8125rem] leading-relaxed text-white/70">
                  {dict.order.sendTelegramHint}
                </p>
                <a
                  href={telegramShareHref}
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-primary mt-3 w-full sm:w-auto"
                >
                  <Icon name="telegram" className="h-4 w-4" />
                  {dict.order.sendTelegram} · {CONTACTS.telegramHandle}
                </a>
              </div>

              <div className="mt-4 flex flex-wrap gap-3">
                <Link href={`/${locale}/track?code=${order.code}`} className="btn btn-ghost">
                  <Icon name="search" className="h-4 w-4" />
                  {dict.order.trackCta}
                </Link>
                <Link href={`/${locale}#order`} className="btn btn-ghost">
                  {dict.order.newOrder}
                  <Icon name="arrow" className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>

          <aside className="space-y-4">
            <div className="card p-5">
              <h2 className="text-sm font-bold text-white">{dict.footer.contactsTitle}</h2>
              <p className="mt-1.5 text-[0.75rem] leading-relaxed text-white/45">
                {dict.footer.hours}
              </p>
              <div className="mt-4 space-y-2.5">
                <a href={CONTACTS.phoneHref} className="btn btn-primary w-full !py-2.5">
                  <Icon name="phone" className="h-4 w-4" />
                  {dict.order.callCta}
                </a>
                <a
                  href={CONTACTS.telegram}
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-ghost w-full !py-2.5"
                >
                  <Icon name="telegram" className="h-4 w-4" />
                  {dict.order.telegramCta}
                </a>
              </div>
              <div className="mt-4 space-y-2 border-t border-white/8 pt-4 text-[0.75rem] text-white/55">
                <p className="flex items-center gap-2">
                  <Icon name="truck" className="h-4 w-4 text-[var(--color-brand)]" />
                  {dict.common.freeDelivery}
                </p>
                <p className="flex items-center gap-2">
                  <Icon name="shield" className="h-4 w-4 text-[var(--color-brand)]" />
                  {dict.common.guarantee}
                </p>
              </div>
            </div>
            <div className="card p-5">
              <h2 className="text-sm font-bold text-white">{dict.form.payment}</h2>
              <p className="mt-2 text-[0.75rem] leading-relaxed text-white/50">
                {dict.info.deliverySections[1].text}
              </p>
              <Link
                href={`/${locale}/info/delivery`}
                className="mt-3 inline-flex items-center gap-1.5 text-[0.75rem] font-semibold text-[var(--color-brand)] hover:underline"
              >
                {dict.footer.delivery}
                <Icon name="arrow" className="h-3.5 w-3.5" />
              </Link>
            </div>
          </aside>
        </div>
      </div>
    </SiteShell>
  );
}
