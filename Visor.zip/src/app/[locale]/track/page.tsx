import Link from "next/link";
import { notFound } from "next/navigation";
import { CONTACTS, isLocale } from "@/lib/constants";
import { getDictionary } from "@/i18n";
import { getOrderByCode } from "@/lib/orders";
import { formatDate, formatPrice } from "@/lib/format";
import { SiteShell } from "@/components/site-shell";
import { TrackForm } from "@/components/track-form";
import { Icon } from "@/components/icons";

export const dynamic = "force-dynamic";

export default async function TrackPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ code?: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const dict = getDictionary(locale);
  const { code } = await searchParams;
  const order = code ? await getOrderByCode(code) : null;
  const statusLabel = order
    ? dict.order.statuses[order.status as keyof typeof dict.order.statuses]
    : null;

  return (
    <SiteShell locale={locale} dict={dict}>
      <div className="container-page max-w-3xl py-12 md:py-20">
        <p className="eyebrow">
          <span className="h-px w-6 bg-[var(--color-brand)]/60" />
          {dict.track.eyebrow}
        </p>
        <h1 className="mt-3 text-3xl font-extrabold sm:text-4xl">{dict.track.title}</h1>
        <p className="mt-3 text-sm text-white/55">{dict.track.text}</p>

        <div className="card mt-7 p-5 sm:p-6">
          <TrackForm locale={locale} dict={dict} initialCode={code ?? ""} />

          {code && !order && (
            <div className="mt-5 flex items-start gap-3 rounded-xl border border-red-500/25 bg-red-500/8 px-4 py-3 text-sm text-red-300">
              <Icon name="close" className="mt-0.5 h-4 w-4 shrink-0" />
              <div>
                <p>{dict.track.notFound}</p>
                <a
                  href={CONTACTS.telegram}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-2 inline-flex items-center gap-1.5 font-semibold text-white hover:underline"
                >
                  <Icon name="telegram" className="h-3.5 w-3.5" />
                  {dict.track.help}
                </a>
              </div>
            </div>
          )}

          {order && (
            <div className="mt-6 rounded-2xl border border-[var(--color-mint)]/25 bg-[var(--color-mint)]/[0.06] p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-[0.625rem] uppercase tracking-[0.16em] text-white/45">
                    {dict.order.codeLabel}
                  </p>
                  <p className="text-lg font-extrabold text-white">{order.code}</p>
                </div>
                <span className="rounded-full border border-[var(--color-brand)]/40 bg-[var(--color-brand)]/12 px-3 py-1.5 text-xs font-bold text-[var(--color-brand)]">
                  {statusLabel}
                </span>
              </div>
              <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
                <div>
                  <dt className="text-[0.6875rem] text-white/40">{dict.form.total}</dt>
                  <dd className="font-semibold text-white">{formatPrice(order.total, locale)}</dd>
                </div>
                <div>
                  <dt className="text-[0.6875rem] text-white/40">{dict.order.deliveryTo}</dt>
                  <dd className="font-semibold text-white">
                    {order.city}, {order.region}
                  </dd>
                </div>
                <div>
                  <dt className="text-[0.6875rem] text-white/40">{dict.order.qty}</dt>
                  <dd className="font-semibold text-white">
                    {order.qty} {dict.common.each}
                  </dd>
                </div>
                <div>
                  <dt className="text-[0.6875rem] text-white/40">{dict.admin.date}</dt>
                  <dd className="font-semibold text-white">{formatDate(order.createdAt, locale)}</dd>
                </div>
              </dl>
              <Link
                href={`/${locale}/order/${order.code}`}
                className="btn btn-ghost mt-4 w-full !py-2.5 sm:w-auto"
              >
                {dict.track.found}
                <Icon name="arrow" className="h-4 w-4" />
              </Link>
            </div>
          )}
        </div>

        <p className="mt-5 text-center text-[0.75rem] text-white/35">
          {dict.footer.hours} · {CONTACTS.phone}
        </p>
      </div>
    </SiteShell>
  );
}
