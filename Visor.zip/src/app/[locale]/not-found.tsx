import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container-page flex min-h-[70vh] flex-col items-center justify-center text-center">
      <p className="eyebrow">404</p>
      <h1 className="mt-4 text-3xl font-extrabold md:text-4xl">Sahifa topilmadi</h1>
      <p className="mt-3 max-w-md text-white/60">
        Kechirasiz, bu sahifa mavjud emas. / Извините, страница не найдена. / Page not found.
      </p>
      <Link href="/uz" className="btn btn-primary mt-8">
        Bosh sahifa
      </Link>
    </div>
  );
}
