import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { isLocale } from "@/lib/constants";
import { getDictionary } from "@/i18n";
import { isAdmin } from "@/lib/admin-auth";
import { getOrderStats, listOrders } from "@/lib/orders";
import { AdminLogin } from "@/components/admin-login";
import { AdminOrders, type AdminOrder } from "@/components/admin-orders";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Carstore_sam Admin",
  robots: { index: false, follow: false },
};

export default async function AdminPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const dict = getDictionary(locale);

  if (!(await isAdmin())) {
    return <AdminLogin locale={locale} dict={dict} />;
  }

  const [orders, stats] = await Promise.all([listOrders("all"), getOrderStats()]);
  const serialized: AdminOrder[] = orders.map((order) => ({
    id: order.id,
    code: order.code,
    customerName: order.customerName,
    phone: order.phone,
    region: order.region,
    city: order.city,
    address: order.address,
    bundleCode: order.bundleCode,
    qty: order.qty,
    total: order.total,
    status: order.status,
    deliveryMethod: order.deliveryMethod,
    comment: order.comment,
    source: order.source,
    createdAt: order.createdAt.toISOString(),
  }));

  return (
    <AdminOrders
      locale={locale}
      dict={dict}
      orders={serialized}
      stats={{
        total: stats.total,
        new: stats.new,
        delivered: stats.delivered,
        revenue: stats.revenue,
      }}
    />
  );
}
