import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { isLocale, CONTACTS } from "@/lib/constants";
import { getDictionary } from "@/i18n";
import { getBundles, getReviews } from "@/lib/products";
import { countOrdersToday } from "@/lib/orders";
import { formatNumber, formatPrice } from "@/lib/format";
import { SiteShell } from "@/components/site-shell";
import { Hero } from "@/components/hero";
import { OrderForm } from "@/components/order-form";
import { FaqAccordion } from "@/components/faq";
import { StickyBar } from "@/components/sticky-bar";
import { Icon, Stars } from "@/components/icons";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  if (!isLocale(locale)) return {};
  return {};
}

export default async function LandingPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const dict = getDictionary(locale);

  const [bundles, reviews, ordersToday] = await Promise.all([
    getBundles(),
    getReviews(locale),
    countOrdersToday(),
  ]);

  const rating = reviews.length
    ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
    : 0;
  const reviewCount = reviews.length;
  const cheapestBundle = bundles.reduce<(typeof bundles)[number] | undefined>(
    (cheapest, bundle) => !cheapest || bundle.price < cheapest.price ? bundle : cheapest,
    undefined,
  );
  const safeFromPrice = cheapestBundle?.price ?? null;
  const popularBundle = bundles.find((bundle) => bundle.badge === "popular") ?? bundles[0];

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: "Carstore_sam Day & Night Anti-Glare Visor",
    image: ["/images/hero-visor.jpg", "/images/day-lens.jpg", "/images/night-lens.jpg"],
    description: dict.meta.description,
    brand: { "@type": "Brand", name: "Carstore_sam" },
    ...(reviewCount > 0 ? { aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: rating.toFixed(1),
      reviewCount,
    } } : {}),
    ...(safeFromPrice !== null ? { offers: {
      "@type": "AggregateOffer",
      priceCurrency: "UZS",
      lowPrice: safeFromPrice,
      highPrice: Math.max(...bundles.map((bundle) => bundle.price)),
      availability: "https://schema.org/InStock",
    } } : {}),
  };

  return (
    <SiteShell locale={locale} dict={dict}>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <Hero
        locale={locale}
        dict={dict}
        rating={rating}
        reviewCount={reviewCount}
        fromPrice={safeFromPrice}
        comparePrice={cheapestBundle?.compareAt ?? null}
        todayOrders={ordersToday}
      />

      {/* trust strip */}
      <section className="border-y border-white/8 bg-white/[0.015]">
        <div className="container-page grid grid-cols-2 gap-x-4 gap-y-6 py-7 md:grid-cols-4">
          {dict.trust.map((item, index) => {
            const icons = ["truck", "card", "bolt", "shield"] as const;
            return (
              <div key={item.title} className="flex items-start gap-3">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-[var(--color-brand)]/25 bg-[var(--color-brand)]/8 text-[var(--color-brand)]">
                  <Icon name={icons[index] ?? "shield"} className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-[0.8125rem] font-semibold leading-tight text-white">
                    {item.title}
                  </p>
                  <p className="mt-1 text-[0.6875rem] leading-snug text-white/45">
                    {item.text}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* compare */}
      <section id="product" className="container-page py-14 md:py-20">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          <div className="relative order-2 lg:order-1">
            <div className="card overflow-hidden p-2">
              <div className="relative aspect-[4/3.1] overflow-hidden rounded-[1.15rem]">
                <Image
                  src="/images/day-lens.jpg"
                  alt={dict.compare.imageAlt}
                  fill
                  sizes="(max-width: 1024px) 100vw, 560px"
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <span className="absolute bottom-4 left-4 rounded-full border border-white/20 bg-black/55 px-3 py-1.5 text-[0.6875rem] font-semibold text-white/85 backdrop-blur">
                  {dict.hero.dayTitle}
                </span>
              </div>
            </div>
            <div className="absolute -bottom-5 -right-3 hidden rounded-2xl border border-[var(--color-brand)]/35 bg-[#0d1119]/95 px-4 py-3 shadow-[var(--shadow-glow)] backdrop-blur sm:block">
              <p className="text-[0.625rem] uppercase tracking-[0.16em] text-white/45">
                {dict.form.payment}
              </p>
              <p className="text-sm font-bold text-[var(--color-brand)]">
                {dict.common.cod}
              </p>
            </div>
          </div>

          <div className="order-1 lg:order-2">
            <p className="eyebrow">
              <span className="h-px w-6 bg-[var(--color-brand)]/60" />
              {dict.compare.eyebrow}
            </p>
            <h2 className="mt-3 text-[1.75rem] font-extrabold leading-tight sm:text-4xl">
              {dict.compare.title}
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-white/55 sm:text-[0.95rem]">
              {dict.compare.text}
            </p>

            <div className="mt-7 grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-white/8 bg-white/[0.02] p-4">
                <p className="flex items-center gap-2 text-[0.8125rem] font-semibold text-white/50">
                  <Icon name="close" className="h-4 w-4 text-red-400/80" />
                  {dict.compare.withoutTitle}
                </p>
                <ul className="mt-3 space-y-2.5">
                  {dict.compare.without.map((item) => (
                    <li key={item} className="text-[0.75rem] leading-snug text-white/40">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-2xl border border-[var(--color-brand)]/30 bg-[var(--color-brand)]/[0.07] p-4">
                <p className="flex items-center gap-2 text-[0.8125rem] font-semibold text-white">
                  <Icon name="check" className="h-4 w-4 text-[var(--color-mint)]" />
                  {dict.compare.withTitle}
                </p>
                <ul className="mt-3 space-y-2.5">
                  {dict.compare.with.map((item) => (
                    <li key={item} className="text-[0.75rem] leading-snug text-white/75">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* lenses */}
      <section id="lenses" className="relative overflow-hidden py-14 md:py-20">
        <div
          className="pointer-events-none absolute inset-0 -z-10"
          style={{
            background:
              "radial-gradient(800px 400px at 15% 20%, rgba(120,160,220,0.09), transparent 60%), radial-gradient(700px 400px at 90% 80%, rgba(255,176,32,0.1), transparent 60%)",
          }}
        />
        <div className="container-page">
          <div className="max-w-2xl">
            <p className="eyebrow">
              <span className="h-px w-6 bg-[var(--color-brand)]/60" />
              {dict.lenses.eyebrow}
            </p>
            <h2 className="mt-3 text-[1.75rem] font-extrabold leading-tight sm:text-4xl">
              {dict.lenses.title}
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-white/55 sm:text-[0.95rem]">
              {dict.lenses.text}
            </p>
          </div>

          <div className="mt-9 grid gap-5 md:grid-cols-2">
            {[
              {
                image: "/images/day-lens.jpg",
                alt: dict.hero.heroImageAlt,
                icon: "sun" as const,
                title: dict.lenses.dayTitle,
                text: dict.lenses.dayText,
                bullets: dict.lenses.dayBullets,
                accent: "from-[#dfe9f4]/20",
              },
              {
                image: "/images/night-lens.jpg",
                alt: dict.hero.nightTitle,
                icon: "moon" as const,
                title: dict.lenses.nightTitle,
                text: dict.lenses.nightText,
                bullets: dict.lenses.nightBullets,
                accent: "from-[var(--color-brand)]/20",
              },
            ].map((card) => (
              <article key={card.title} className="card overflow-hidden">
                <div className="relative aspect-[16/9]">
                  <Image
                    src={card.image}
                    alt={card.alt}
                    fill
                    sizes="(max-width: 768px) 100vw, 560px"
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0b0e14] via-[#0b0e14]/20 to-transparent" />
                  <span className="absolute left-4 top-4 grid h-10 w-10 place-items-center rounded-full border border-white/20 bg-black/45 text-white backdrop-blur">
                    <Icon name={card.icon} className="h-5 w-5" />
                  </span>
                </div>
                <div className="p-5">
                  <h3 className="text-lg font-bold tracking-tight">{card.title}</h3>
                  <p className="mt-2 text-[0.8125rem] leading-relaxed text-white/55">
                    {card.text}
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {card.bullets.map((bullet) => (
                      <span
                        key={bullet}
                        className="rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-1 text-[0.6875rem] text-white/60"
                      >
                        {bullet}
                      </span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
          <p className="mt-5 flex items-start gap-2 text-[0.75rem] leading-relaxed text-white/35">
            <Icon name="shield" className="mt-0.5 h-4 w-4 shrink-0" />
            {dict.lenses.note}
          </p>
        </div>
      </section>

      {/* how it works */}
      <section id="how" className="border-y border-white/8 bg-white/[0.015] py-14 md:py-20">
        <div className="container-page grid gap-10 lg:grid-cols-[1fr_0.9fr] lg:gap-14">
          <div>
            <p className="eyebrow">
              <span className="h-px w-6 bg-[var(--color-brand)]/60" />
              {dict.how.eyebrow}
            </p>
            <h2 className="mt-3 text-[1.75rem] font-extrabold leading-tight sm:text-4xl">
              {dict.how.title}
            </h2>
            <p className="mt-4 max-w-lg text-sm leading-relaxed text-white/55 sm:text-[0.95rem]">
              {dict.how.text}
            </p>

            <ol className="mt-8 space-y-5">
              {dict.how.steps.map((step, index) => (
                <li key={step.title} className="flex gap-4">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[var(--color-brand)]/40 bg-[var(--color-brand)]/10 text-sm font-bold text-[var(--color-brand)]">
                    {index + 1}
                  </span>
                  <div>
                    <h3 className="text-[0.9375rem] font-semibold text-white">{step.title}</h3>
                    <p className="mt-1 max-w-md text-[0.8125rem] leading-relaxed text-white/50">
                      {step.text}
                    </p>
                  </div>
                </li>
              ))}
            </ol>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link href={`/${locale}#order`} className="btn btn-primary">
                {dict.common.orderNow}
                <Icon name="arrow" className="h-4 w-4" />
              </Link>
              <a href={CONTACTS.telegram} target="_blank" rel="noreferrer" className="btn btn-ghost">
                <Icon name="telegram" className="h-4 w-4" />
                {CONTACTS.telegramHandle}
              </a>
            </div>
          </div>

          <div>
            <div className="card overflow-hidden p-2">
              <div className="relative aspect-[4/3] overflow-hidden rounded-[1.15rem]">
                <Image
                  src="/images/install.jpg"
                  alt={dict.how.imageAlt}
                  fill
                  sizes="(max-width: 1024px) 100vw, 480px"
                  className="object-cover"
                />
                <span className="absolute bottom-3 left-3 rounded-full border border-white/20 bg-black/55 px-3 py-1.5 text-[0.6875rem] font-semibold text-white/85 backdrop-blur">
                  10 sec
                </span>
              </div>
            </div>

            <div className="card mt-4 p-5">
              <h3 className="text-[0.6875rem] font-semibold uppercase tracking-[0.18em] text-white/40">
                {dict.how.specsTitle}
              </h3>
              <dl className="mt-3 divide-y divide-white/8">
                {dict.how.specs.map((spec) => (
                  <div key={spec.label} className="flex items-start justify-between gap-4 py-2">
                    <dt className="text-[0.75rem] text-white/45">{spec.label}</dt>
                    <dd className="text-right text-[0.75rem] font-medium text-white/85">
                      {spec.value}
                    </dd>
                  </div>
                ))}
              </dl>
              <p className="mt-3 text-[0.6875rem] leading-relaxed text-white/35">
                {dict.how.fitNote}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* offer + order form */}
      <section id="offer" className="container-page py-14 md:py-20">
        <div className="grid gap-10 lg:grid-cols-[0.95fr_1fr] lg:gap-14">
          <div>
            <p className="eyebrow">
              <span className="h-px w-6 bg-[var(--color-brand)]/60" />
              {dict.offer.eyebrow}
            </p>
            <h2 className="mt-3 text-[1.75rem] font-extrabold leading-tight sm:text-4xl">
              {dict.offer.title}
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-white/55 sm:text-[0.95rem]">
              {dict.offer.text}
            </p>

            <div className="mt-7 space-y-3">
              {bundles.map((bundle) => {
                const copy = dict.offer.bundles[bundle.code as keyof typeof dict.offer.bundles];
                const save = bundle.compareAt - bundle.price;
                const isPopular = bundle.badge === "popular";
                return (
                  <div
                    key={bundle.code}
                    className={`relative flex items-center justify-between gap-4 rounded-2xl border p-4 ${
                      isPopular
                        ? "border-[var(--color-brand)]/45 bg-[var(--color-brand)]/[0.07]"
                        : "border-white/10 bg-white/[0.02]"
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-white/10 bg-black/30 text-[var(--color-brand)]">
                        <Icon name="package" className="h-5 w-5" />
                      </span>
                      <div>
                        <p className="flex flex-wrap items-center gap-2 text-[0.9375rem] font-semibold text-white">
                          {copy?.name}
                          {isPopular && (
                            <span className="rounded-full bg-[var(--color-brand)] px-2 py-0.5 text-[0.5625rem] font-bold uppercase tracking-wide text-[#16110a]">
                              {dict.common.popular}
                            </span>
                          )}
                        </p>
                        <p className="mt-0.5 text-[0.75rem] text-white/45">{copy?.desc}</p>
                      </div>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="text-[0.9375rem] font-bold text-white">
                        {formatNumber(bundle.price)}
                      </p>
                      <p className="text-[0.6875rem] text-white/35 line-through">
                        {formatNumber(bundle.compareAt)}
                      </p>
                      <p className="text-[0.625rem] font-medium text-[var(--color-mint)]">
                        −{formatNumber(save)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-6 flex items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.02] p-4">
              <Icon name="star" className="mt-0.5 h-4 w-4 shrink-0 text-[var(--color-brand)]" />
              <p className="text-[0.8125rem] leading-relaxed text-white/70">{dict.offer.bonus}</p>
            </div>

            <div className="card mt-4 flex items-center gap-4 p-4">
              <Image
                src="/images/product-flat.jpg"
                alt="Carstore_sam visor"
                width={96}
                height={96}
                className="h-20 w-20 rounded-xl object-cover"
              />
              <div>
                <p className="text-sm font-semibold text-white">Carstore_sam Day &amp; Night</p>
                <p className="mt-1 text-[0.75rem] leading-relaxed text-white/45">
                  {dict.lenses.title} · {dict.common.guarantee}
                </p>
                {popularBundle && (
                  <p className="mt-1.5 text-[0.8125rem] font-bold text-[var(--color-brand)]">
                    {formatPrice(popularBundle.price, locale)}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div id="order" className="scroll-mt-24">
            <OrderForm locale={locale} dict={dict} bundles={bundles} />
          </div>
        </div>
      </section>

      {/* reviews */}
      <section id="reviews" className="border-y border-white/8 bg-white/[0.015] py-14 md:py-20">
        <div className="container-page">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="eyebrow">
                <span className="h-px w-6 bg-[var(--color-brand)]/60" />
                {dict.reviewsSection.eyebrow}
              </p>
              <h2 className="mt-3 text-[1.75rem] font-extrabold leading-tight sm:text-4xl">
                {dict.reviewsSection.title}
              </h2>
            </div>
            {reviewCount > 0 && (
              <div className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3">
                <span className="text-2xl font-extrabold text-white">{rating.toFixed(1)}</span>
                <div>
                  <Stars rating={rating} />
                  <p className="mt-1 text-[0.6875rem] text-white/45">
                    {reviewCount} {dict.reviewsSection.basedOn}
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {reviewCount === 0 && <p className="text-sm text-white/55">{dict.reviewsSection.empty}</p>}
            {reviews.slice(0, 9).map((review) => (
              <article
                key={review.id}
                className="card flex flex-col justify-between p-5 transition hover:border-white/20"
              >
                <div>
                  <div className="flex items-center justify-between gap-3">
                    <Stars rating={review.rating} className="h-3.5 w-3.5" />
                    <span className="flex items-center gap-1 text-[0.625rem] text-[var(--color-mint)]">
                      <Icon name="check" className="h-3 w-3" />
                      {dict.reviewsSection.verified}
                    </span>
                  </div>
                  <p className="mt-3 text-[0.8125rem] leading-relaxed text-white/75">
                    “{review.body}”
                  </p>
                </div>
                <div className="mt-4 flex items-center gap-3 border-t border-white/8 pt-3">
                  <span className="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br from-[#2a3546] to-[#151b25] text-[0.6875rem] font-bold text-white/80">
                    {review.name.slice(0, 1)}
                  </span>
                  <div>
                    <p className="text-[0.75rem] font-semibold text-white/85">{review.name}</p>
                    <p className="text-[0.625rem] text-white/40">
                      {review.city}
                      {review.car ? ` · ${review.car}` : ""}
                    </p>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* guarantee */}
      <section className="container-page py-14 md:py-20">
        <div className="relative overflow-hidden rounded-[1.75rem] border border-[var(--color-brand)]/25 bg-gradient-to-br from-[var(--color-brand)]/[0.13] via-[#11161f] to-[#0b0e14] p-6 sm:p-10">
          <div className="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-[var(--color-brand)]/20 blur-3xl" />
          <div className="relative grid gap-8 md:grid-cols-[1.2fr_1fr] md:items-center">
            <div>
              <p className="eyebrow">{dict.guarantee.eyebrow}</p>
              <h2 className="mt-3 text-2xl font-extrabold leading-tight sm:text-3xl">
                {dict.guarantee.title}
              </h2>
              <p className="mt-3 max-w-xl text-sm leading-relaxed text-white/60">
                {dict.guarantee.text}
              </p>
              <div className="mt-5 flex flex-wrap gap-3">
                <a href={CONTACTS.phoneHref} className="btn btn-primary">
                  <Icon name="phone" className="h-4 w-4" />
                  {dict.guarantee.cta}
                </a>
                <a
                  href={CONTACTS.telegram}
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-ghost"
                >
                  <Icon name="telegram" className="h-4 w-4" />
                  Telegram
                </a>
              </div>
            </div>
            <ul className="space-y-3">
              {dict.guarantee.bullets.map((bullet) => (
                <li
                  key={bullet}
                  className="flex items-start gap-3 rounded-xl border border-white/10 bg-black/25 px-4 py-3 text-[0.8125rem] text-white/75"
                >
                  <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[var(--color-mint)]/15 text-[var(--color-mint)]">
                    <Icon name="check" className="h-3 w-3" strokeWidth={2.6} />
                  </span>
                  {bullet}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* faq */}
      <section id="faq" className="container-page pb-14 md:pb-20">
        <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr] lg:gap-14">
          <div>
            <p className="eyebrow">
              <span className="h-px w-6 bg-[var(--color-brand)]/60" />
              {dict.faq.eyebrow}
            </p>
            <h2 className="mt-3 text-[1.75rem] font-extrabold leading-tight sm:text-4xl">
              {dict.faq.title}
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-white/55">{dict.faq.intro}</p>
            <div className="card mt-6 space-y-3 p-5">
              <a
                href={CONTACTS.phoneHref}
                className="flex items-center gap-2.5 text-sm text-white/75 hover:text-white"
              >
                <Icon name="phone" className="h-4 w-4 text-[var(--color-brand)]" />
                {CONTACTS.phone}
              </a>
              <a
                href={CONTACTS.telegram}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2.5 text-sm text-white/75 hover:text-white"
              >
                <Icon name="telegram" className="h-4 w-4 text-[var(--color-brand)]" />
                {CONTACTS.telegramHandle}
              </a>
              <Link
                href={`/${locale}/track`}
                className="flex items-center gap-2.5 text-sm text-white/75 hover:text-white"
              >
                <Icon name="search" className="h-4 w-4 text-[var(--color-brand)]" />
                {dict.nav.track}
              </Link>
              <p className="border-t border-white/8 pt-3 text-[0.6875rem] text-white/35">
                {dict.footer.hours}
              </p>
            </div>
          </div>
          <FaqAccordion items={dict.faq.items} />
        </div>
      </section>

      {/* final CTA */}
      <section className="container-page pb-16">
        <div className="relative overflow-hidden rounded-[1.75rem] border border-white/10 bg-gradient-to-br from-[#1b2431] via-[#121822] to-[#0a0e14] px-6 py-10 text-center sm:px-12 sm:py-14">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[var(--color-brand)]/70 to-transparent" />
          <div className="pointer-events-none absolute -bottom-24 left-1/2 h-64 w-[28rem] -translate-x-1/2 rounded-full bg-[var(--color-brand)]/15 blur-3xl" />
          <div className="relative mx-auto max-w-2xl">
            <p className="eyebrow justify-center">{dict.finalCta.eyebrow}</p>
            <h2 className="mt-3 text-[1.65rem] font-extrabold leading-tight sm:text-4xl">
              {dict.finalCta.title}
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-white/55">
              {dict.finalCta.text}
            </p>
            <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
              <Link href={`/${locale}#order`} className="btn btn-primary">
                {dict.finalCta.cta}
                <Icon name="arrow" className="h-4 w-4" />
              </Link>
              <a
                href={CONTACTS.telegram}
                target="_blank"
                rel="noreferrer"
                className="btn btn-ghost"
              >
                <Icon name="telegram" className="h-4 w-4" />
                {dict.finalCta.secondary}
              </a>
            </div>
            <p className="mt-4 text-[0.6875rem] text-white/35">
              {dict.common.freeDelivery} · {dict.common.cod} · {dict.common.guarantee}
            </p>
          </div>
        </div>
      </section>

      {safeFromPrice !== null && <StickyBar locale={locale} price={safeFromPrice} label={dict.common.orderNow} />}
    </SiteShell>
  );
}
