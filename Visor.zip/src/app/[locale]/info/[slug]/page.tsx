import Link from "next/link";
import { notFound } from "next/navigation";
import { CONTACTS, isLocale } from "@/lib/constants";
import { getDictionary } from "@/i18n";
import { SiteShell } from "@/components/site-shell";
import { Icon } from "@/components/icons";

export const dynamic = "force-static";

const SLUGS = ["delivery", "warranty"] as const;

export function generateStaticParams() {
  return ["uz", "ru", "en"].flatMap((locale) => SLUGS.map((slug) => ({ locale, slug })));
}

export default async function InfoPage({
  params,
}: {
  params: Promise<{ locale: string; slug: string }>;
}) {
  const { locale, slug } = await params;
  if (!isLocale(locale)) notFound();
  if (!SLUGS.includes(slug as (typeof SLUGS)[number])) notFound();
  const dict = getDictionary(locale);

  const isDelivery = slug === "delivery";
  const title = isDelivery ? dict.info.deliveryTitle : dict.info.warrantyTitle;
  const intro = isDelivery ? dict.info.deliveryIntro : dict.info.warrantyIntro;
  const sections = isDelivery ? dict.info.deliverySections : dict.info.warrantySections;

  return (
    <SiteShell locale={locale} dict={dict}>
      <div className="container-page max-w-4xl py-12 md:py-20">
        <p className="eyebrow">
          <span className="h-px w-6 bg-[var(--color-brand)]/60" />
          Carstore_sam
        </p>
        <h1 className="mt-3 text-3xl font-extrabold sm:text-4xl">{title}</h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-white/55">{intro}</p>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {sections.map((section) => (
            <article key={section.title} className="card p-5">
              <h2 className="text-[0.9375rem] font-bold text-white">{section.title}</h2>
              <p className="mt-2 text-[0.8125rem] leading-relaxed text-white/55">{section.text}</p>
            </article>
          ))}
        </div>

        <div className="mt-6 grid gap-3 rounded-2xl border border-white/10 bg-white/[0.02] p-5 sm:grid-cols-3">
          <a href={CONTACTS.phoneHref} className="flex items-center gap-2 text-sm text-white/75 hover:text-white">
            <Icon name="phone" className="h-4 w-4 text-[var(--color-brand)]" />
            {CONTACTS.phone}
          </a>
          <a
            href={CONTACTS.telegram}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 text-sm text-white/75 hover:text-white"
          >
            <Icon name="telegram" className="h-4 w-4 text-[var(--color-brand)]" />
            {CONTACTS.telegramHandle}
          </a>
          <span className="flex items-center gap-2 text-sm text-white/50">
            <Icon name="clock" className="h-4 w-4" />
            {dict.footer.hours}
          </span>
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <Link href={`/${locale}#order`} className="btn btn-primary">
            {dict.common.orderNow}
            <Icon name="arrow" className="h-4 w-4" />
          </Link>
          <Link href={`/${locale}`} className="btn btn-ghost">
            {dict.common.backHome}
          </Link>
          <Link
            href={`/${locale}/info/${isDelivery ? "warranty" : "delivery"}`}
            className="btn btn-ghost"
          >
            {isDelivery ? dict.info.warrantyTitle : dict.info.deliveryTitle}
          </Link>
        </div>
      </div>
    </SiteShell>
  );
}
