import type { MetadataRoute } from "next";
import { LOCALES } from "@/lib/constants";
import { getSiteUrl } from "@/lib/site-url";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{
      userAgent: "*",
      allow: "/",
      disallow: ["/api/", ...LOCALES.map((locale) => `/${locale}/admin`), ...LOCALES.map((locale) => `/${locale}/order/`)],
    }],
    sitemap: `${getSiteUrl()}/sitemap.xml`,
  };
}
