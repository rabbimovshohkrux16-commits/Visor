import { NextResponse } from "next/server";
import { getDb } from "@/db";
import { orders } from "@/db/schema";
import { getBundles } from "@/lib/products";
import { getOrderByCode } from "@/lib/orders";
import { generateOrderCode, normalizePhone } from "@/lib/format";
import { isLocale } from "@/lib/constants";
import { notifyNewOrder } from "@/lib/notify";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
// Allow time for a Neon cold start and the awaited notification channels.
export const maxDuration = 30;

type Payload = {
  locale?: string;
  bundleCode?: string;
  name?: string;
  phone?: string;
  region?: string;
  city?: string;
  address?: string;
  comment?: string;
  deliveryMethod?: string;
  source?: string;
};

function clean(value: unknown, max: number) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

export async function POST(request: Request) {
  let body: Payload;
  try {
    const parsed: unknown = await request.json();
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return NextResponse.json({ ok: false, error: "bad_request" }, { status: 400 });
    }
    body = parsed as Payload;
  } catch {
    return NextResponse.json({ ok: false, error: "bad_request" }, { status: 400 });
  }

  const name = clean(body.name, 120);
  const phone = normalizePhone(clean(body.phone, 32));
  const region = clean(body.region, 64);
  const city = clean(body.city, 96);
  const deliveryMethod = body.deliveryMethod === "pickup" ? "pickup" : "courier";
  const address = deliveryMethod === "pickup" ? clean(body.address, 300) || "Olib ketish" : clean(body.address, 300);
  const comment = clean(body.comment, 500);
  const locale = isLocale(body.locale) ? body.locale : "ru";
  const source = clean(body.source, 120);

  if (name.length < 2) {
    return NextResponse.json({ ok: false, error: "name" }, { status: 422 });
  }
  if (!phone) {
    return NextResponse.json({ ok: false, error: "phone" }, { status: 422 });
  }
  if (!region || city.length < 2 || address.length < 3) {
    return NextResponse.json({ ok: false, error: "address" }, { status: 422 });
  }

  try {
    // Prices and available bundles must come from the actual database.
    const bundles = await getBundles();
    const bundle = bundles.find((item) => item.code === body.bundleCode);
    if (!bundle) {
      return NextResponse.json({ ok: false, error: "bundle" }, { status: 422 });
    }

    const database = getDb();
    for (let attempt = 0; attempt < 6; attempt += 1) {
      const code = generateOrderCode();
      const [created] = await database
        .insert(orders)
        .values({
          code,
          locale,
          bundleCode: bundle.code,
          qty: bundle.qty,
          unitPrice: Math.round(bundle.price / bundle.qty),
          total: bundle.price,
          deliveryFee: 0,
          currency: "UZS",
          customerName: name,
          phone,
          region,
          city,
          address,
          comment: comment || null,
          deliveryMethod,
          paymentMethod: "card_on_delivery",
          source: source || null,
          status: "new",
        })
        // Avoid a race between checking for an existing code and inserting it.
        .onConflictDoNothing({ target: orders.code })
        .returning({ code: orders.code });

      if (created) {
        // An unavailable notification channel must not turn a saved order into
        // an apparent checkout failure and cause the customer to order twice.
        try {
          await notifyNewOrder({
            code: created.code,
            customerName: name,
            phone,
            region,
            city,
            address,
            deliveryMethod,
            qty: bundle.qty,
            total: bundle.price,
            comment: comment || null,
            source: source || null,
            locale,
          });
        } catch (error) {
          console.error("Order was saved, but notification could not be sent:", error);
        }
        return NextResponse.json({ ok: true, code: created.code }, { status: 201 });
      }
    }
    return NextResponse.json({ ok: false, error: "code" }, { status: 500 });
  } catch (error) {
    console.error("Order creation failed:", error);
    return NextResponse.json({ ok: false, error: "server" }, { status: 503 });
  }
}

export async function GET(request: Request) {
  const code = new URL(request.url).searchParams.get("code");
  if (!code) {
    return NextResponse.json({ ok: false, error: "missing_code" }, { status: 400 });
  }

  try {
    const order = await getOrderByCode(code);
    if (!order) {
      return NextResponse.json({ ok: false, error: "not_found" }, { status: 404 });
    }
    return NextResponse.json({
      ok: true,
      order: {
        code: order.code,
        status: order.status,
        createdAt: order.createdAt,
        bundleCode: order.bundleCode,
        qty: order.qty,
        total: order.total,
        city: order.city,
      },
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Order lookup failed:", error);
    return NextResponse.json({ ok: false, error: "server" }, { status: 503 });
  }
}
