import { getDb } from "@/db";
import { bundles, orders, reviews, settings } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/** Readiness: PostgreSQL must be reachable and the schema must be migrated. */
export async function GET() {
  try {
    const database = getDb();
    await Promise.all([
      database.execute(sql`select 1 from ${bundles} limit 0`),
      database.execute(sql`select 1 from ${orders} limit 0`),
      database.execute(sql`select 1 from ${reviews} limit 0`),
      database.execute(sql`select 1 from ${settings} limit 0`),
    ]);
    return Response.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Database readiness check failed:", error instanceof Error ? error.message : error);
    return Response.json({ ok: false }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
