import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/admin-auth";
import { markOrderStatus } from "@/lib/orders";
import { ORDER_STATUSES } from "@/lib/constants";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await isAdmin())) {
    return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const orderId = Number(id);
  if (!Number.isSafeInteger(orderId) || orderId < 1) {
    return NextResponse.json({ ok: false, error: "bad_id" }, { status: 400 });
  }

  let status = "";
  try {
    const body = (await request.json()) as { status?: string };
    status = body.status ?? "";
  } catch {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  if (!(ORDER_STATUSES as readonly string[]).includes(status)) {
    return NextResponse.json({ ok: false, error: "bad_status" }, { status: 422 });
  }

  try {
    const updated = await markOrderStatus(orderId, status);
    if (!updated) {
      return NextResponse.json({ ok: false, error: "not_found" }, { status: 404 });
    }
    return NextResponse.json({ ok: true, status: updated.status });
  } catch (error) {
    console.error("status update failed", error);
    return NextResponse.json({ ok: false, error: "server" }, { status: 500 });
  }
}
