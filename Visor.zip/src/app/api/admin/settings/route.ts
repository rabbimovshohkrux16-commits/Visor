import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/admin-auth";
import { getNotifyConfig, getSettings, setSetting } from "@/lib/settings";
import { sendEmail, sendTelegram } from "@/lib/notify";
import { CONTACTS, SITE_NAME } from "@/lib/constants";

export const dynamic = "force-dynamic";

function mask(value?: string) {
  if (!value) return "";
  if (value.length <= 6) return "••••";
  return `${value.slice(0, 4)}••••${value.slice(-4)}`;
}

async function status() {
  const [stored, config] = await Promise.all([getSettings(), getNotifyConfig()]);
  return {
    telegram: {
      connected: !!config.telegram,
      fromEnv: !!config.telegram?.fromEnv,
      tokenMasked: mask(stored.telegram_bot_token),
      hasToken: !!stored.telegram_bot_token,
      chatLabel: config.telegram?.label ?? "",
    },
    email: {
      connected: !!config.email,
      fromEnv: !!config.email?.fromEnv,
      host: stored.smtp_host ?? "smtp.gmail.com",
      port: stored.smtp_port ?? "465",
      user: stored.smtp_user ?? CONTACTS.email,
      hasPass: !!stored.smtp_pass,
      to: stored.notify_email ?? CONTACTS.email,
    },
  };
}

export async function GET() {
  if (!(await isAdmin())) {
    return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }
  try {
    return NextResponse.json({ ok: true, ...(await status()) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Could not read notification settings:", error instanceof Error ? error.message : error);
    return NextResponse.json({ ok: false, error: "server" }, { status: 503 });
  }
}

type Body = {
  action?: string;
  token?: string;
  host?: string;
  port?: string;
  user?: string;
  pass?: string;
  to?: string;
};

type TelegramUpdate = {
  message?: {
    chat?: { id: number; type: string; username?: string; first_name?: string; title?: string };
  };
};

export async function POST(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }

  let body: Body;
  try {
    const parsed: unknown = await request.json();
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return NextResponse.json({ ok: false, error: "bad_request" }, { status: 400 });
    }
    body = parsed as Body;
  } catch {
    return NextResponse.json({ ok: false, error: "bad_request" }, { status: 400 });
  }

  try {
    switch (body.action) {
      case "save_telegram": {
        const token = (body.token ?? "").trim();
        if (token) {
          const me = await fetch(`https://api.telegram.org/bot${token}/getMe`, {
            signal: AbortSignal.timeout(8000),
          });
          if (!me.ok) {
            return NextResponse.json({ ok: false, error: "bad_token" }, { status: 422 });
          }
        }
        const previous = await getSettings();
        if (previous.telegram_bot_token !== token) {
          await setSetting("telegram_chat_id", "");
          await setSetting("telegram_chat_label", "");
        }
        await setSetting("telegram_bot_token", token);
        return NextResponse.json({ ok: true, ...(await status()) });
      }

      case "connect_telegram": {
        const stored = await getSettings();
        const token = stored.telegram_bot_token;
        if (!token) {
          return NextResponse.json({ ok: false, error: "no_token" }, { status: 422 });
        }
        const updatesRes = await fetch(`https://api.telegram.org/bot${token}/getUpdates?limit=100`, {
          signal: AbortSignal.timeout(8000),
        });
        if (!updatesRes.ok) {
          return NextResponse.json({ ok: false, error: "bad_token" }, { status: 422 });
        }
        const data = (await updatesRes.json()) as { result?: TelegramUpdate[] };
        const chats = (data.result ?? [])
          .map((update) => update.message?.chat)
          .filter((chat): chat is NonNullable<TelegramUpdate["message"]>["chat"] & object => !!chat);
        if (chats.length === 0) {
          return NextResponse.json({ ok: false, error: "no_chat" }, { status: 422 });
        }
        // Never send customers' personal data to an unrelated chat that happened
        // to message the bot first. Other chat IDs can be configured via env.
        const preferred = [...chats].reverse().find(
          (chat) => chat.type === "private" && chat.username?.toLowerCase() === CONTACTS.telegramUser.toLowerCase(),
        );
        if (!preferred) {
          return NextResponse.json({ ok: false, error: "no_chat" }, { status: 422 });
        }
        const label = preferred.username
          ? `@${preferred.username}`
          : preferred.first_name ?? preferred.title ?? String(preferred.id);
        await setSetting("telegram_chat_id", String(preferred.id));
        await setSetting("telegram_chat_label", label);
        await sendTelegram(
          { token, chatId: String(preferred.id), label, fromEnv: false },
          `✅ ${SITE_NAME}: уведомления о заказах подключены.\nBuyurtma bildirishnomalari ulandi.`,
        );
        return NextResponse.json({ ok: true, ...(await status()) });
      }

      case "test_telegram": {
        const config = await getNotifyConfig();
        if (!config.telegram) {
          return NextResponse.json({ ok: false, error: "no_chat" }, { status: 422 });
        }
        await sendTelegram(config.telegram, `🔔 ${SITE_NAME}: тестовое сообщение / sinov xabari`);
        return NextResponse.json({ ok: true, ...(await status()) });
      }

      case "save_email": {
        const host = (body.host ?? "").trim();
        const port = (body.port ?? "465").trim();
        const user = (body.user ?? "").trim();
        const pass = (body.pass ?? "").trim();
        const to = (body.to ?? "").trim();
        const portNumber = Number(port);
        if (!Number.isInteger(portNumber) || portNumber < 1 || portNumber > 65535) {
          return NextResponse.json({ ok: false, error: "bad_port" }, { status: 422 });
        }
        if (to && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to)) {
          return NextResponse.json({ ok: false, error: "bad_email" }, { status: 422 });
        }
        await setSetting("smtp_host", host);
        await setSetting("smtp_port", port);
        await setSetting("smtp_user", user);
        if (pass) await setSetting("smtp_pass", pass);
        if (!host && !user) await setSetting("smtp_pass", "");
        await setSetting("notify_email", to);
        return NextResponse.json({ ok: true, ...(await status()) });
      }

      case "test_email": {
        const config = await getNotifyConfig();
        if (!config.email) {
          return NextResponse.json({ ok: false, error: "no_email" }, { status: 422 });
        }
        await sendEmail(
          config.email,
          `${SITE_NAME}: тестовое письмо`,
          "Уведомления о заказах подключены. / Buyurtma bildirishnomalari ulandi.",
        );
        return NextResponse.json({ ok: true, ...(await status()) });
      }

      default:
        return NextResponse.json({ ok: false, error: "unknown_action" }, { status: 400 });
    }
  } catch (error) {
    console.error("Settings action failed:", error instanceof Error ? error.name : "unknown error");
    return NextResponse.json({ ok: false, error: "failed" }, { status: 500 });
  }
}
