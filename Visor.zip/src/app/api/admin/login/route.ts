import { NextResponse } from "next/server";
import { adminCookie, checkPassword, isAdminConfigured } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!isAdminConfigured()) {
    console.error("Administrator login unavailable: ADMIN_PASSWORD is not configured.");
    return NextResponse.json({ ok: false, error: "not_configured" }, { status: 503 });
  }

  let password: string;
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== "object" || !("password" in body) || typeof body.password !== "string") {
      return NextResponse.json({ ok: false, error: "bad_request" }, { status: 400 });
    }
    password = body.password;
  } catch {
    return NextResponse.json({ ok: false, error: "bad_request" }, { status: 400 });
  }

  if (!checkPassword(password)) {
    return NextResponse.json({ ok: false, error: "invalid" }, { status: 401 });
  }

  const response = NextResponse.json({ ok: true });
  response.cookies.set(adminCookie.name, adminCookie.value(), adminCookie.options);
  return response;
}

export async function DELETE() {
  const response = NextResponse.json({ ok: true });
  response.cookies.set(adminCookie.name, "", { path: "/", maxAge: 0, httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" });
  return response;
}
