import { NextResponse, type NextRequest } from "next/server";
import { DEFAULT_LOCALE, LOCALES } from "@/lib/constants";

const locales: readonly string[] = LOCALES;

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const first = pathname.split("/")[1];

  if (locales.includes(first)) {
    return NextResponse.next();
  }

  const cookieLocale = request.cookies.get("dw_locale")?.value;
  const accept = request.headers.get("accept-language") ?? "";
  let locale: string = DEFAULT_LOCALE;

  if (cookieLocale && locales.includes(cookieLocale)) {
    locale = cookieLocale;
  } else if (/^ru\b|,ru\b/.test(accept)) {
    locale = "ru";
  } else if (/^en\b|,en\b/.test(accept)) {
    locale = "en";
  }

  const url = request.nextUrl.clone();
  url.pathname = `/${locale}${pathname === "/" ? "" : pathname}`;
  return NextResponse.redirect(url);
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|images|favicon.ico|icon.svg|.*\\..*).*)"],
};
