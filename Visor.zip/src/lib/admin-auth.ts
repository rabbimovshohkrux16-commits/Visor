import { cookies } from "next/headers";
import { createHash, createHmac, timingSafeEqual } from "node:crypto";

const COOKIE_NAME = "dw_admin";
const SESSION_SECONDS = 60 * 60 * 12;

function passwordFromEnvironment() {
  return process.env.ADMIN_PASSWORD || "";
}

export function isAdminConfigured() {
  return passwordFromEnvironment().length > 0;
}

function constantTimeEqual(left: string, right: string) {
  const leftHash = createHash("sha256").update(left).digest();
  const rightHash = createHash("sha256").update(right).digest();
  return timingSafeEqual(leftHash, rightHash);
}

function signSession(issuedAt: string, password: string) {
  return createHmac("sha256", password)
    .update(`carstore-admin-v1:${issuedAt}`)
    .digest("hex");
}

function createSessionToken() {
  const password = passwordFromEnvironment();
  if (!password) throw new Error("ADMIN_PASSWORD is not configured.");
  const issuedAt = String(Math.floor(Date.now() / 1000));
  return `${issuedAt}.${signSession(issuedAt, password)}`;
}

export function checkPassword(password: string) {
  const expected = passwordFromEnvironment();
  return !!expected && constantTimeEqual(password, expected);
}

export async function isAdmin() {
  const password = passwordFromEnvironment();
  if (!password) return false;

  const token = (await cookies()).get(COOKIE_NAME)?.value;
  if (!token) return false;
  const parts = token.split(".");
  if (parts.length !== 2 || !/^\d+$/.test(parts[0]) || !/^[a-f0-9]{64}$/.test(parts[1])) {
    return false;
  }
  const issuedAt = Number(parts[0]);
  const now = Math.floor(Date.now() / 1000);
  if (!Number.isSafeInteger(issuedAt) || issuedAt > now + 60 || now - issuedAt >= SESSION_SECONDS) {
    return false;
  }
  return constantTimeEqual(parts[1], signSession(parts[0], password));
}

export const adminCookie = {
  name: COOKIE_NAME,
  value: createSessionToken,
  options: {
    httpOnly: true,
    sameSite: "lax" as const,
    path: "/",
    maxAge: SESSION_SECONDS,
    secure: process.env.NODE_ENV === "production",
  },
};
