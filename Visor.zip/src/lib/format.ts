import type { Locale } from "./constants";

const currencyLabel: Record<Locale, string> = {
  uz: "so'm",
  ru: "сум",
  en: "UZS",
};

export function formatPrice(value: number, locale: Locale = "uz") {
  const digits = Math.round(value)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `${digits} ${currencyLabel[locale]}`;
}

export function formatNumber(value: number) {
  return Math.round(value)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

export function formatDate(value: Date | string, locale: Locale = "uz") {
  const date = typeof value === "string" ? new Date(value) : value;
  const map: Record<Locale, string> = { uz: "uz-UZ", ru: "ru-RU", en: "en-GB" };
  try {
    return new Intl.DateTimeFormat(map[locale], {
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  } catch {
    return date.toISOString().slice(0, 16).replace("T", " ");
  }
}

/** Normalizes an Uzbek phone number to +998XXXXXXXXX, returns null if invalid. */
export function normalizePhone(input: string): string | null {
  const digits = input.replace(/\D/g, "");
  const local = digits.startsWith("998") ? digits.slice(3) : digits;
  if (local.length !== 9) return null;
  return `+998${local}`;
}

export function prettyPhone(phone: string) {
  const local = phone.replace(/\D/g, "").slice(-9);
  if (local.length !== 9) return phone;
  return `+998 ${local.slice(0, 2)} ${local.slice(2, 5)} ${local.slice(5, 7)} ${local.slice(7, 9)}`;
}

export function generateOrderCode() {
  const random = Math.floor(100000 + Math.random() * 900000);
  return `CS-${random}`;
}
