export const LOCALES = ["uz", "ru", "en"] as const;
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = "uz";

export function isLocale(value: string | undefined): value is Locale {
  return !!value && (LOCALES as readonly string[]).includes(value);
}

export const SITE_NAME = "Carstore_sam";

export const CONTACTS = {
  phone: "+998 97 928 06 24",
  phoneHref: "tel:+998979280624",
  phoneDigits: "998979280624",
  telegram: "https://t.me/vip024rbv",
  telegramHandle: "@vip024rbv",
  telegramUser: "vip024rbv",
  instagram: "https://instagram.com/vip024rbv",
  instagramHandle: "@vip024rbv",
  email: "shorabbimov@gmail.com",
  city: { uz: "Samarqand", ru: "Самарканд", en: "Samarkand" } as Record<Locale, string>,
};

export type RegionOption = { value: string; label: Record<Locale, string> };

export const REGIONS: RegionOption[] = [
  { value: "Samarqand viloyati", label: { uz: "Samarqand viloyati", ru: "Самаркандская область", en: "Samarkand region" } },
  { value: "Toshkent shahri", label: { uz: "Toshkent shahri", ru: "г. Ташкент", en: "Tashkent city" } },
  { value: "Toshkent viloyati", label: { uz: "Toshkent viloyati", ru: "Ташкентская область", en: "Tashkent region" } },
  { value: "Andijon viloyati", label: { uz: "Andijon viloyati", ru: "Андижанская область", en: "Andijan region" } },
  { value: "Buxoro viloyati", label: { uz: "Buxoro viloyati", ru: "Бухарская область", en: "Bukhara region" } },
  { value: "Farg'ona viloyati", label: { uz: "Farg'ona viloyati", ru: "Ферганская область", en: "Fergana region" } },
  { value: "Jizzax viloyati", label: { uz: "Jizzax viloyati", ru: "Джизакская область", en: "Jizzakh region" } },
  { value: "Xorazm viloyati", label: { uz: "Xorazm viloyati", ru: "Хорезмская область", en: "Khorezm region" } },
  { value: "Namangan viloyati", label: { uz: "Namangan viloyati", ru: "Наманганская область", en: "Namangan region" } },
  { value: "Navoiy viloyati", label: { uz: "Navoiy viloyati", ru: "Навоийская область", en: "Navoi region" } },
  { value: "Qashqadaryo viloyati", label: { uz: "Qashqadaryo viloyati", ru: "Кашкадарьинская область", en: "Kashkadarya region" } },
  { value: "Qoraqalpog'iston", label: { uz: "Qoraqalpog'iston Respublikasi", ru: "Республика Каракалпакстан", en: "Karakalpakstan" } },
  { value: "Sirdaryo viloyati", label: { uz: "Sirdaryo viloyati", ru: "Сырдарьинская область", en: "Syrdarya region" } },
  { value: "Surxondaryo viloyati", label: { uz: "Surxondaryo viloyati", ru: "Сурхандарьинская область", en: "Surkhandarya region" } },
];

export const ORDER_STATUSES = [
  "new",
  "confirmed",
  "shipped",
  "delivered",
  "cancelled",
] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];
