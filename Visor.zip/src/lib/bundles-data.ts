export type BundleView = {
  code: string;
  qty: number;
  price: number;
  compareAt: number;
  badge: string | null;
  sortOrder: number;
};

export const DEFAULT_BUNDLES: BundleView[] = [
  { code: "single", qty: 1, price: 219000, compareAt: 320000, badge: null, sortOrder: 1 },
  { code: "duo", qty: 2, price: 379000, compareAt: 640000, badge: "popular", sortOrder: 2 },
  { code: "trio", qty: 3, price: 519000, compareAt: 960000, badge: "best", sortOrder: 3 },
];
