import { and, desc, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { bundles as bundlesTable, reviews as reviewsTable } from "@/db/schema";
import { ensureSeed } from "@/db/seed";
import type { Locale } from "./constants";
import type { Review } from "@/db/schema";
import type { BundleView } from "./bundles-data";

export type { BundleView };

export async function getBundles(): Promise<BundleView[]> {
  await ensureSeed();
  const rows = await getDb()
    .select()
    .from(bundlesTable)
    .where(eq(bundlesTable.active, true))
    .orderBy(bundlesTable.sortOrder);

  return rows.map((row) => ({
    code: row.code,
    qty: row.qty,
    price: row.price,
    compareAt: row.compareAt,
    badge: row.badge,
    sortOrder: row.sortOrder,
  }));
}

export async function getReviews(locale: Locale): Promise<Review[]> {
  const database = getDb();
  const rows = await database
    .select()
    .from(reviewsTable)
    .where(and(eq(reviewsTable.visible, true), eq(reviewsTable.locale, locale)))
    .orderBy(desc(reviewsTable.createdAt))
    .limit(12);
  if (rows.length > 0) return rows;

  return database
    .select()
    .from(reviewsTable)
    .where(eq(reviewsTable.visible, true))
    .orderBy(desc(reviewsTable.createdAt))
    .limit(12);
}

export function getBundleFromList(list: BundleView[], code: string): BundleView | undefined {
  return list.find((bundle) => bundle.code === code);
}
