import { eq, inArray } from "drizzle-orm";
import { getDb } from "@/db";
import { settings } from "@/db/schema";
import { CONTACTS } from "./constants";

export const SETTING_KEYS = [
  "telegram_bot_token",
  "telegram_chat_id",
  "telegram_chat_label",
  "smtp_host",
  "smtp_port",
  "smtp_user",
  "smtp_pass",
  "notify_email",
] as const;
export type SettingKey = (typeof SETTING_KEYS)[number];

export async function getSettings(): Promise<Partial<Record<SettingKey, string>>> {
  const rows = await getDb()
    .select()
    .from(settings)
    .where(inArray(settings.key, [...SETTING_KEYS]));
  const map: Partial<Record<SettingKey, string>> = {};
  for (const row of rows) {
    map[row.key as SettingKey] = row.value;
  }
  return map;
}

export async function setSetting(key: SettingKey, value: string) {
  const database = getDb();
  if (!value) {
    await database.delete(settings).where(eq(settings.key, key));
    return;
  }
  await database
    .insert(settings)
    .values({ key, value, updatedAt: new Date() })
    .onConflictDoUpdate({ target: settings.key, set: { value, updatedAt: new Date() } });
}

export type NotifyConfig = {
  telegram: { token: string; chatId: string; label: string; fromEnv: boolean } | null;
  email: {
    host: string;
    port: number;
    user: string;
    pass: string;
    to: string;
    fromEnv: boolean;
  } | null;
};

/** Environment variables take priority over settings saved by the administrator. */
export async function getNotifyConfig(): Promise<NotifyConfig> {
  const stored = await getSettings();
  const envToken = process.env.TELEGRAM_BOT_TOKEN;
  const envChat = process.env.TELEGRAM_CHAT_ID;
  const telegram =
    envToken && envChat
      ? { token: envToken, chatId: envChat, label: "env", fromEnv: true }
      : stored.telegram_bot_token && stored.telegram_chat_id
        ? {
            token: stored.telegram_bot_token,
            chatId: stored.telegram_chat_id,
            label: stored.telegram_chat_label ?? "",
            fromEnv: false,
          }
        : null;

  const envHost = process.env.SMTP_HOST;
  const envUser = process.env.SMTP_USER;
  const envPass = process.env.SMTP_PASS;
  const email =
    envHost && envUser && envPass
      ? {
          host: envHost,
          port: Number(process.env.SMTP_PORT || 465),
          user: envUser,
          pass: envPass,
          to: process.env.NOTIFY_EMAIL || CONTACTS.email,
          fromEnv: true,
        }
      : stored.smtp_host && stored.smtp_user && stored.smtp_pass
        ? {
            host: stored.smtp_host,
            port: Number(stored.smtp_port || 465),
            user: stored.smtp_user,
            pass: stored.smtp_pass,
            to: stored.notify_email || CONTACTS.email,
            fromEnv: false,
          }
        : null;

  return { telegram, email };
}
