import { count, desc, eq, gte, sql } from "drizzle-orm";
import { getDb } from "@/db";
import { orders } from "@/db/schema";
import type { Order } from "@/db/schema";

export function startOfToday() {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

export async function countOrdersToday(): Promise<number> {
  const rows = await getDb()
    .select({ value: count() })
    .from(orders)
    .where(gte(orders.createdAt, startOfToday()));
  return Number(rows[0]?.value ?? 0);
}

export async function getOrderByCode(code: string): Promise<Order | null> {
  const rows = await getDb()
    .select()
    .from(orders)
    .where(eq(orders.code, code.trim().toUpperCase()))
    .limit(1);
  return rows[0] ?? null;
}

export async function listOrders(status?: string): Promise<Order[]> {
  const database = getDb();
  if (status && status !== "all") {
    return database
      .select()
      .from(orders)
      .where(eq(orders.status, status))
      .orderBy(desc(orders.createdAt))
      .limit(300);
  }
  return database.select().from(orders).orderBy(desc(orders.createdAt)).limit(300);
}

export async function getOrderStats() {
  const rows = await getDb()
    .select({
      status: orders.status,
      total: count(),
      revenue: sql<number>`coalesce(sum(${orders.total}), 0)`,
    })
    .from(orders)
    .groupBy(orders.status);

  const stats = {
    total: 0,
    new: 0,
    confirmed: 0,
    shipped: 0,
    delivered: 0,
    cancelled: 0,
    revenue: 0,
  };
  for (const row of rows) {
    const amount = Number(row.total ?? 0);
    stats.total += amount;
    if (["new", "confirmed", "shipped", "delivered", "cancelled"].includes(row.status)) {
      stats[row.status as "new" | "confirmed" | "shipped" | "delivered" | "cancelled"] = amount;
    }
    if (row.status === "delivered") stats.revenue += Number(row.revenue ?? 0);
  }
  return stats;
}

export async function markOrderStatus(id: number, status: string) {
  const [updated] = await getDb()
    .update(orders)
    .set({ status })
    .where(eq(orders.id, id))
    .returning();
  return updated ?? null;
}
