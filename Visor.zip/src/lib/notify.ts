import nodemailer from "nodemailer";
import { getNotifyConfig, type NotifyConfig } from "./settings";
import { SITE_NAME } from "./constants";

export type NotifyOrder = {
  code: string;
  customerName: string;
  phone: string;
  region: string;
  city: string;
  address: string;
  deliveryMethod: string;
  qty: number;
  total: number;
  comment?: string | null;
  source?: string | null;
  locale: string;
};

function formatSum(value: number) {
  return `${value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ")} so'm`;
}

function buildLines(order: NotifyOrder) {
  const delivery =
    order.deliveryMethod === "pickup"
      ? "Самовывоз (Самарканд) / Olib ketish"
      : `Курьер / Kuryer: ${order.city}, ${order.region}, ${order.address}`;
  return [
    `🆕 Новый заказ / Yangi buyurtma — ${SITE_NAME}`,
    `№ ${order.code}`,
    `👤 ${order.customerName}`,
    `📞 ${order.phone}`,
    `📦 ${order.qty} × Day & Night visor`,
    `💰 ${formatSum(order.total)} (доставка — обсудить)`,
    "💳 Оплата картой при получении / Olishda karta orqali to'lov",
    `🚚 ${delivery}`,
    order.comment ? `💬 ${order.comment}` : null,
    order.source ? `📈 ${order.source}` : null,
    `🌐 ${order.locale}`,
  ].filter((line): line is string => Boolean(line));
}

export async function sendTelegram(
  telegram: NonNullable<NotifyConfig["telegram"]>,
  text: string,
) {
  const response = await fetch(`https://api.telegram.org/bot${telegram.token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: telegram.chatId,
      text,
      disable_web_page_preview: true,
    }),
    signal: AbortSignal.timeout(8000),
  });
  if (!response.ok) {
    throw new Error(`telegram ${response.status}`);
  }
}

export async function sendEmail(
  email: NonNullable<NotifyConfig["email"]>,
  subject: string,
  text: string,
) {
  const transporter = nodemailer.createTransport({
    host: email.host,
    port: email.port,
    secure: email.port === 465,
    auth: { user: email.user, pass: email.pass },
    connectionTimeout: 8000,
    greetingTimeout: 8000,
    socketTimeout: 10000,
  });
  await transporter.sendMail({
    from: `"${SITE_NAME}" <${email.user}>`,
    to: email.to,
    subject,
    text,
  });
}

/**
 * Sends a new-order alert to the seller via Telegram and/or email.
 * Channels are configured in the admin panel (or via env variables).
 */
export async function notifyNewOrder(order: NotifyOrder) {
  const config = await getNotifyConfig();
  const text = buildLines(order).join("\n");
  const tasks: Promise<void>[] = [];

  if (config.telegram) {
    tasks.push(
      sendTelegram(config.telegram, text).catch((error) =>
        console.error("telegram notify failed", error),
      ),
    );
  }
  if (config.email) {
    tasks.push(
      sendEmail(config.email, `Новый заказ ${order.code} — ${SITE_NAME}`, text).catch((error) =>
        console.error("email notify failed", error),
      ),
    );
  }

  await Promise.allSettled(tasks);
}
