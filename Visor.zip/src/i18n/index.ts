import type { Locale } from "@/lib/constants";
import { uz } from "./uz";
import { ru } from "./ru";
import { en } from "./en";

export type { Dictionary } from "./uz";

const dictionaries = { uz, ru, en } as const;

export function getDictionary(locale: Locale) {
  return dictionaries[locale] ?? dictionaries.uz;
}

export const localeLabels: Record<Locale, string> = {
  uz: "O'zbekcha",
  ru: "Русский",
  en: "English",
};

export const localeShort: Record<Locale, string> = {
  uz: "UZ",
  ru: "RU",
  en: "EN",
};
