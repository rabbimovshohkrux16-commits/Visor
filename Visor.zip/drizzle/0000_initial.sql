CREATE TABLE "bundles" (
	"id" serial PRIMARY KEY NOT NULL,
	"code" varchar(32) NOT NULL,
	"qty" integer NOT NULL,
	"price" integer NOT NULL,
	"compare_at" integer NOT NULL,
	"badge" varchar(32),
	"sort_order" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	CONSTRAINT "bundles_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "orders" (
	"id" serial PRIMARY KEY NOT NULL,
	"code" varchar(24) NOT NULL,
	"locale" varchar(4) DEFAULT 'ru' NOT NULL,
	"bundle_code" varchar(32) NOT NULL,
	"qty" integer NOT NULL,
	"unit_price" integer NOT NULL,
	"total" integer NOT NULL,
	"delivery_fee" integer DEFAULT 0 NOT NULL,
	"currency" varchar(8) DEFAULT 'UZS' NOT NULL,
	"customer_name" varchar(120) NOT NULL,
	"phone" varchar(32) NOT NULL,
	"region" varchar(64) NOT NULL,
	"city" varchar(96) NOT NULL,
	"address" text NOT NULL,
	"comment" text,
	"delivery_method" varchar(24) DEFAULT 'courier' NOT NULL,
	"payment_method" varchar(24) DEFAULT 'card_on_delivery' NOT NULL,
	"source" varchar(120),
	"status" varchar(24) DEFAULT 'new' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "orders_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "reviews" (
	"id" serial PRIMARY KEY NOT NULL,
	"locale" varchar(4) NOT NULL,
	"name" varchar(80) NOT NULL,
	"city" varchar(80) NOT NULL,
	"rating" integer DEFAULT 5 NOT NULL,
	"body" text NOT NULL,
	"car" varchar(80),
	"visible" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "settings" (
	"key" varchar(64) PRIMARY KEY NOT NULL,
	"value" text NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
